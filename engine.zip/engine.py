"""週内の授業交換。GUIに依存しない制約判定。"""
from dataclasses import dataclass
from collections import defaultdict
from itertools import combinations
import re, unicodedata
import time
import copy

SLOTS = [f'{d}{p}' for d,n in zip('月火水木金',(6,6,6,5,6)) for p in range(1,n+1)]
DAY_SLOTS={d:tuple(s for s,label in enumerate(SLOTS) if label[0]==d) for d in '月火水木金'}
PRIORITIES = {
    'full_days':'その曜日の授業が満タンになる先生を少なくする',
    'people':'変更に関わる先生の人数を少なくする',
    'same_day':'できるだけ同じ曜日の中で変更する',
}

FIXED_SUBJECTS = {'学活','総合','音美総','学総','学道総','作業','作業2','アイロン'}

RULES = {
    'same_day_only':'同じ曜日の中で変更',
    'movement_same_grade':'同じ学年の先生のみ',
    'daily_free':'空きコマ1以上',
    'science_limit':'理科の同時授業数を制限',
    'music_limit':'音楽の同時授業数を制限',
    'art_limit':'美術の同時授業数を制限',
    'pe_limit':'保体の同時授業数を制限（各学年）',
    'pe_no_late':'保体を５限・６限に入れない',
    'special_fixed':'10・11・12組の授業を動かさない（作業・アイロンを含む）',
    'combined_fixed':'音美総を固定する',
    'homeroom_fixed':'学活を固定する',
    'integrated_1_fixed':'１年総合を固定する',
    'integrated_2_fixed':'２年総合を固定する',
    'integrated_3_fixed':'３年総合を固定する',
    'special_activity_fixed':'特活を固定する',
    'operation_fixed':'運営を固定する',
    'student_guidance_fixed':'生徒指を固定する',
    'learning_fixed':'まなびを固定する',
    'club_fixed':'〇部を固定する',
    'librarian_fixed':'司書を固定する',
    'support_fixed':'支援を固定する',
    'initial_training_fixed':'初任研を固定する',
    'sc_fixed':'SCを固定する',
    'foreign_fixed':'外国人を固定する',
    'allow_unavailable_edit':'勤務不可を編集できる',
}

def is_study_subject(subject):
    return subject.endswith('自習')

def study_subject(subject):
    return subject if is_study_subject(subject) else subject+'自習'

def exchange_category(subject):
    if re.fullmatch(r'外国人[0-9]*',subject):return '外国人'
    if subject=='支援':return '支援'
    return None

def exchange_key(lesson):
    category=exchange_category(lesson.subject)
    return ('予定',category) if category else ('授業',lesson.classes) if lesson.classes else ('予定',lesson.subject)

def fixed_duty(text):
    return text in {'特活','運営','まなび','生徒指','司書','支援','初任研','SC'} or text.endswith('部') or bool(re.fullmatch('[123]年総合',text))

def duty_rule(text):
    if re.fullmatch('[123]年総合',text):return f'integrated_{text[0]}_fixed'
    if text=='特活':return 'special_activity_fixed'
    if text=='運営':return 'operation_fixed'
    if text=='生徒指':return 'student_guidance_fixed'
    if text=='まなび':return 'learning_fixed'
    if text=='司書':return 'librarian_fixed'
    if text=='支援':return 'support_fixed'
    if text=='初任研':return 'initial_training_fixed'
    if text=='SC':return 'sc_fixed'
    if exchange_category(text)=='外国人':return 'foreign_fixed'
    if text.endswith('部'):return 'club_fixed'
    return None

def fixed_by_conditions(classes,subject,rules):
    key=duty_rule(subject)
    return bool((key is not None and rules[key])
                or ('10' in classes and rules['special_fixed'])
                or (subject=='音美総' and rules['combined_fixed'])
                or (subject=='学活' and rules['homeroom_fixed'])
                or (subject in {'総合','学総','学道総'} and any(rules[f'integrated_{c[0]}_fixed'] for c in classes if '-' in c and c[0] in '123'))
                or (subject in {'作業','アイロン'} and rules['special_fixed']))

def parse_cell(value):
    value=unicodedata.normalize('NFKC',str(value or '')).strip()
    if value in ('','-'): return ('free',(),'',False)
    if value in ('/','／','×','X'): return ('blocked',(),'',True)
    if value.startswith('?') or value.startswith('？'): return ('unknown',(),value,True)
    locked=value.startswith('!')
    text=value[1:] if locked else value
    m=re.fullmatch(r'(\d-[\d.]+|10[・.,]11[・.,]12)\s+(.+)',text)
    if not m and (exchange_category(text) or text=='初任研' or is_study_subject(text)):return ('lesson',(),text,False)
    if not m: return ('duty',(),text,True) if locked or fixed_duty(text) else ('unknown',(),text,True)
    key,subject=m.groups()
    if key.startswith('10'): classes=('10','11','12')
    else:
        grade,nums=key.split('-'); classes=tuple(f'{grade}-{n}' for n in nums.split('.'))
        if grade not in '123' or any(not n.isdigit() or not 1<=int(n)<=12 for n in nums.split('.')):
            return ('unknown',(),text,True)
    if len(set(classes))!=len(classes): return ('unknown',(),text,True)
    subject={'体育':'保体','保健体育':'保体','作業2':'作業'}.get(subject,subject)
    return ('lesson',tuple(sorted(classes)),subject,locked or '10' in classes or subject in FIXED_SUBJECTS or fixed_duty(subject))

@dataclass(frozen=True)
class Lesson:
    id: str
    classes: tuple
    subject: str
    teachers: tuple
    origin: int
    locked: bool=False

class Model:
    def __init__(self,data):
        # Old exports added ! to all moral education lessons automatically.
        # Migrate only that legacy marker, preserving saved lesson positions.
        if data.get('rules_version',1)<2:
            for teacher in data['teachers']:
                teacher['cells']=[re.sub(r'^!(?=\d-[\d.]+\s+道徳$)','',str(v or '')) for v in teacher['cells']]
            data['rules_version']=2
        self.data=data
        defaults={'science':3,'music':1,'art':1,'pe1':1,'pe2':1,'pe3':1}
        self.room_limits=defaults|data.get('room_limits',{})
        if set(self.room_limits)!=set(defaults) or any(type(v)!=int or not 1<=v<=5 for v in self.room_limits.values()):raise ValueError('同時最大数は1～5で設定してください。')
        self.data['room_limits']=dict(self.room_limits)
        self.data['study_settings']={'same_grade':True,'max_count':1,'limit_enabled':True}|data.get('study_settings',{})
        self.data['study_settings'].pop('daily_free',None)  # Legacy per-study switch is superseded by the common rule.
        study=self.data['study_settings']
        if type(study['limit_enabled']) is not bool or type(study['same_grade']) is not bool or type(study['max_count']) is not int or not 1<=study['max_count']<=5:raise ValueError('自習対応の条件が不正です。')
        self.study_requests={tuple(x) for x in data.get('study_requests',[])}
        # Old preference metadata stays readable but no longer weakens hard rules.
        self.priorities=list(PRIORITIES)
        self.priority_enabled=set()
        conditions=dict(data.get('conditions',{}))
        for key in ('homeroom_fixed','integrated_fixed'):conditions.setdefault(key,conditions.get('other_fixed',True))
        for grade in '123':conditions.setdefault(f'integrated_{grade}_fixed',conditions['integrated_fixed'])
        self.rules={k:conditions.get(k,k not in ('same_day_only','movement_same_grade','allow_unavailable_edit','support_fixed','initial_training_fixed','foreign_fixed')) for k in RULES}
        self.rules['slash_fixed']=True
        if any(type(v) is not bool for v in self.rules.values()):raise ValueError('条件設定が不正です。')
        self.teachers={t['id']:t['name'] for t in data['teachers']}
        if any(len(c)!=2 or c[0] not in self.teachers or type(c[1]) is not int or c[1] not in range(len(SLOTS)) for c in self.study_requests):raise ValueError('自習対応の指定が不正です。')
        self.manual_fixed={(str(t),int(s)) for t,s in data.get('manual_fixed',[])}
        if any(t not in self.teachers or s not in range(len(SLOTS)) for t,s in self.manual_fixed):raise ValueError('固定コマの設定が不正です。')
        if len(self.teachers)!=len(data['teachers']):raise ValueError('先生IDが重複しています。')
        self.blocked=set(); self.unknown=[]; groups={}
        training_roster={tuple(cell):tuple(sorted(t for t,_ in record['cells'])) for record in data.get('joint_links',[]) if record['subject']=='初任研' for cell in record['cells']}
        training_at=defaultdict(set)
        for t in data['teachers']:
            for slot,value in enumerate(t['cells']):
                if parse_cell(value)[2]=='初任研':training_at[slot].add(training_roster.get((t['id'],slot),()))
        for t in data['teachers']:
            if len(t['cells'])!=len(SLOTS):raise ValueError(f"{t['name']} のコマ数が{len(SLOTS)}ではありません。")
            for slot,value in enumerate(t['cells']):
                kind,classes,sub,locked=parse_cell(value)
                if kind=='blocked' and self.rules['slash_fixed']:self.blocked.add((t['id'],slot))
                if kind=='duty' and (duty_rule(sub) is None or self.rules[duty_rule(sub)]):self.blocked.add((t['id'],slot))
                if kind=='unknown':self.blocked.add((t['id'],slot))
                if kind=='unknown':self.unknown.append(f"{t['name']} {SLOTS[slot]}：{value}")
                if kind=='lesson':
                    managed='10' in classes or sub in FIXED_SUBJECTS or duty_rule(sub) is not None or exchange_category(sub) is not None or is_study_subject(sub)
                    explicit=str(value).strip().startswith('!') and not managed
                    duty_key=duty_rule(sub)
                    locked=explicit or fixed_by_conditions(classes,sub,self.rules)
                    # Training at the same period shares its teachers, like a joint lesson.
                    # A period with one teacher remains an independent lesson.
                    owner=t['id'] if not classes and sub!='初任研' else ''
                    if sub=='初任研' and len(training_at[slot])>1:owner='@'+','.join(training_roster.get((t['id'],slot),(t['id'],)))
                    k=(slot,classes,sub,owner)
                    group=groups.setdefault(k,{'teachers':[],'locked':False})
                    group['teachers'].append(t['id']);group['locked']|=locked
        self.lessons={}
        for (slot,classes,sub,owner),g in groups.items():
            lid=f'{slot}:'+','.join(classes)+':'+sub+((':'+owner) if owner else '')
            self.lessons[lid]=Lesson(lid,classes,sub,tuple(sorted(g['teachers'])),slot,g['locked'])
        self.joint_members={k:{k} for k in self.lessons}
        lookup={(t,l.origin):k for k,l in self.lessons.items() for t in l.teachers}
        for record in data.get('joint_links',[]):
            ids={lookup[tuple(cell)] for cell in record['cells'] if tuple(cell) in lookup
                 and self.lessons[lookup[tuple(cell)]].subject==record['subject']
                 and self.lessons[lookup[tuple(cell)]].classes==tuple(record['classes'])}
            merged=set().union(*(self.joint_members[k] for k in ids)) if ids else set()
            for k in merged:self.joint_members[k]=merged
        self.joint_key={k:min(ids) for k,ids in self.joint_members.items()}
        self.joint_sets=[ids for k,ids in self.joint_members.items() if len(ids)>1 and k==self.joint_key[k]]
        # Search-only cover lessons reserve their teacher/class/time without
        # overwriting the ordinary lesson that must first be moved away.
        for i,record in enumerate(data.get('study_plan',[])):
            lid=f'@study:{i}'
            self.lessons[lid]=Lesson(lid,tuple(record['classes']),study_subject(record['subject']),(record['teacher'],),record['slot'],True)
            self.joint_members[lid]={lid};self.joint_key[lid]=lid
        self.initial={lid:l.origin for lid,l in self.lessons.items()}
        from dataclasses import replace
        study_fixed={(r['teacher'],r['slot']) for r in data.get('study_records',[])}
        self.lessons={k:replace(l,locked=True) if is_study_subject(l.subject) and any((t,l.origin) in study_fixed for t in l.teachers) else l for k,l in self.lessons.items()}
        self.lessons={k:replace(l,locked=True) if any((t,l.origin) in self.manual_fixed for t in l.teachers) else l for k,l in self.lessons.items()}
        self.blocked.update((t,s) for t,s in self.manual_fixed if not any(t in l.teachers and s==l.origin for l in self.lessons.values()))
        self.positions=dict(data.get('positions') or self.initial)
        if set(self.positions)<set(self.initial) and all(not self.lessons[k].classes for k in set(self.initial)-set(self.positions)):
            self.positions.update({k:self.initial[k] for k in set(self.initial)-set(self.positions)})
        if set(self.positions)!=set(self.initial):raise ValueError('授業データと保存位置が一致しません。基本表から読み込み直してください。')
        if any(type(s)!=int or not 0<=s<len(SLOTS) for s in self.positions.values()):raise ValueError('保存位置が不正です。')
        reference=data.get('day_reference',{})
        self.day_reference=dict(reference) if set(reference)==set(self.positions) else dict(self.positions)
        # Derive exemptions exclusively from the original weekly table, never
        # from a saved edited timetable or old cached exemption metadata.
        original=data.get('weekly_baseline') or {'teachers':data['teachers']}
        self.free_exempt_days={(t['id'],d) for t in original['teachers'] for d,slots in DAY_SLOTS.items()
                               if all(parse_cell(t['cells'][slot])[0] != 'free' for slot in slots)}
        self.data.pop('free_exempt_teachers',None)
        self.data['free_exempt_days']=sorted(self.free_exempt_days)
        self.absent={(str(t),int(s)) for t,s in data.get('absent',[])}
        if any(t not in self.teachers or not 0<=s<len(SLOTS) for t,s in self.absent):raise ValueError('不在設定が不正です。')
        self.pe_policy=data.get('pe_policy','未設定')
        if self.pe_policy not in ('未設定','別枠','1年','2年','3年','全学年'):raise ValueError('体育設定が不正です。')
        # Capacities belong to the original weekday/period, never an edited plan.
        baseline=data.get('weekly_baseline')
        base=Model({'teachers':copy.deepcopy(baseline['teachers']),'rules_version':3,
                    'conditions':dict(self.rules),'pe_policy':self.pe_policy}) if baseline else self
        sci=base.science(base.initial);rooms=base.arts_rooms(base.initial);pe=base.occupancy(base.initial)[2]
        self.science_capacity={s:max(self.room_limits['science'],base.joint_count(sci.get(s,set()))) for s in range(len(SLOTS))}
        self.room_capacity={(r,s):max(self.room_limits[k],base.joint_count(rooms.get((r,s),set()))) for r,k in [('音楽室','music'),('美術室','art')] for s in range(len(SLOTS))}
        self.pe_capacity={(g,s):max(self.room_limits.get('pe'+g,1),base.joint_count(pe.get((g,s),set()))) for g in ('1','2','3','特別支援','未設定') for s in range(len(SLOTS))}
        self.late_pe_capacity={slot:base.joint_count(ids) for slot,ids in base.late_pe(base.initial).items()}

    def joint_records(self,pos=None):
        pos=self.initial if pos is None else pos
        records=[]
        for k,members in self.joint_members.items():
            if k!=self.joint_key[k]:continue
            cells=sorted({(t,pos[j]) for j in members for t in self.lessons[j].teachers})
            if len(cells)>1 or self.lessons[k].subject=='初任研':records.append({'cells':cells,'classes':list(self.lessons[k].classes),'subject':self.lessons[k].subject})
        return records

    def joint_count(self,ids):
        return len({self.joint_key[k] for k in ids}) if self.joint_sets else len(ids)

    def split_joint(self,pos):
        return {k for ids in self.joint_sets if len({pos[j] for j in ids})>1 for k in ids}

    def expand_joint(self,plan):
        if not self.joint_sets:return {k:s for k,s in plan.items() if self.positions[k]!=s}
        result=dict(plan)
        for k,dest in plan.items():
            for j in self.joint_members[k]:
                if j in result and result[j]!=dest:return None
                if self.lessons[j].locked and self.positions[j]!=dest:return None
                if self.positions[j]!=dest:result[j]=dest
        return {k:s for k,s in result.items() if self.positions[k]!=s}

    def room_conflict(self,room,slot,ids):
        return self.joint_count(ids)>self.room_capacity.get((room,slot),1)

    def late_pe(self,pos):
        buckets=defaultdict(set)
        for lid,slot in pos.items():
            if self.lessons[lid].subject=='保体' and SLOTS[slot][-1] in '56':buckets[slot].add(lid)
        return buckets

    def late_pe_violations(self,pos):
        if not self.rules['pe_no_late']:return {}
        return {slot:ids for slot,ids in self.late_pe(pos).items() if self.joint_count(ids)>self.late_pe_capacity.get(slot,0)}

    def science(self,pos):
        buckets=defaultdict(set)
        for lid,s in pos.items():
            if self.lessons[lid].subject=='理科':buckets[s].add(lid)
        return buckets

    def rooms_used(self,l):
        rooms=('音楽室','美術室') if l.subject=='音美総' else {'音楽':('音楽室',),'美術':('美術室',)}.get(l.subject,())
        return tuple(r for r in rooms if self.rules['music_limit' if r=='音楽室' else 'art_limit'])

    def arts_rooms(self,pos):
        rooms=defaultdict(set)
        for k,s in pos.items():
            for room in self.rooms_used(self.lessons[k]):rooms[room,s].add(k)
        return rooms

    def pe_grades(self,l):
        if l.subject!='保体' or not self.rules['pe_limit']:return ()
        if '10' in l.classes:
            return {'未設定':('未設定',),'別枠':('特別支援',),'全学年':('1','2','3')}.get(self.pe_policy,(self.pe_policy[0],))
        return tuple(sorted({c.split('-')[0] for c in l.classes}))

    def occupancy(self,pos):
        teachers=defaultdict(set);classes=defaultdict(set);pe=defaultdict(set)
        for lid,s in pos.items():
            l=self.lessons[lid]
            for t in l.teachers:teachers[t,s].add(lid)
            for c in l.classes:classes[c,s].add(lid)
            for g in self.pe_grades(l):pe[g,s].add(lid)
        return teachers,classes,pe

    def errors(self,pos,check_absent=True):
        errors=list(self.unknown)
        teachers,classes,pe=self.occupancy(pos)
        for (t,s),ids in teachers.items():
            if len(ids)>1:errors.append(f'{self.teachers[t]} {SLOTS[s]}：授業重複')
            if (t,s) in self.blocked:errors.append(f'{self.teachers[t]} {SLOTS[s]}：勤務不可・固定予定と重複')
            if check_absent and (t,s) in self.absent:errors.append(f'{self.teachers[t]} {SLOTS[s]}：不在に授業あり')
        for (c,s),ids in classes.items():
            if self.joint_count(ids)>1:errors.append(f'{c} {SLOTS[s]}：クラスの授業重複')
        for (g,s),ids in pe.items():
            if self.joint_count(ids)>self.pe_capacity.get((g,s),1):errors.append(f'体育 {g}年 {SLOTS[s]}：{len(ids)}授業')
        for s,ids in self.science(pos).items():
            if self.rules['science_limit'] and self.joint_count(ids)>self.science_capacity.get(s,3):errors.append(f'理科 {SLOTS[s]}：{len(ids)}授業（上限{self.science_capacity.get(s,3)}）')
        for (room,s),ids in self.arts_rooms(pos).items():
            if self.room_conflict(room,s,ids):errors.append(f'{room} {SLOTS[s]}：{len(ids)}授業が重複（上限{self.room_capacity.get((room,s),1)}）')
        for lid,s in pos.items():
            if self.lessons[lid].locked and s!=self.initial[lid]:errors.append(f'{self.label(lid)}：固定授業が移動')
        errors.extend(f'保体 {SLOTS[slot]}：{len(ids)}授業（原本による上限{self.late_pe_capacity.get(slot,0)}）' for slot,ids in self.late_pe_violations(pos).items())
        errors.extend(self.hard_errors(pos))
        errors.extend(self.study_errors(pos))
        return errors

    def study_errors(self,pos):
        records=self.data.get('study_records',[])
        if not records:return []
        settings=self.data['study_settings'];counts=defaultdict(set);errors=[]
        for k,l in self.lessons.items():
            if is_study_subject(l.subject):
                for t in l.teachers:counts[t].add(pos[k])
        for record in records:
            t=record['teacher'];slot=record['slot'];classes=tuple(record['classes'])
            matches=[k for k,l in self.lessons.items() if is_study_subject(l.subject) and l.classes==classes and t in l.teachers and l.origin==slot]
            if not matches:continue
            if settings['limit_enabled'] and len(counts[t])>settings['max_count']:errors.append(f'{self.teachers[t]}：自習対応の週間上限{settings["max_count"]}コマを超えています')
            grades={c.split('-')[0] if '-' in c else '特別支援' for c in classes}
            if settings['same_grade'] and grades!={self.data.get('teacher_grades',{}).get(t,'未設定')}:errors.append(f'{self.teachers[t]}：自習対応の所属学年が一致しません。原本C列を確認してください')
        return list(dict.fromkeys(errors))

    def lesson_count_errors(self):
        """原本と比べたクラス別・教科別の不足と過多を検出する。"""
        baseline=self.data.get('weekly_baseline')
        if not baseline:return []
        expected=defaultdict(int);actual=defaultdict(int);seen=set();special_groups=[]
        for teacher in baseline['teachers']:
            for slot,value in enumerate(teacher['cells']):
                kind,classes,subject,_=parse_cell(value)
                if kind!='lesson':continue
                key=(slot,classes,subject)
                if key in seen:continue
                seen.add(key)
                if subject in ('音美総','技家'):special_groups.append((classes,subject))
                for c in classes:expected[c,subject]+=1
        for lesson in self.lessons.values():
            subject=lesson.subject
            if is_study_subject(subject):
                record=next((r for r in self.data.get('study_records',[]) if r['teacher'] in lesson.teachers and r['slot']==lesson.origin and tuple(r['classes'])==lesson.classes),None)
                if record:subject=record['subject']
            for c in lesson.classes:actual[c,subject]+=1
        delta={key:actual[key]-expected[key] for key in set(expected)|set(actual)}
        def consume_group(classes,subjects,amount):
            for class_name in classes:
                for subject in subjects:
                    key=(class_name,subject);used=min(max(0,delta.get(key,0)),amount)
                    delta[key]=delta.get(key,0)-used;amount-=used
                    if amount==0:return 0
            return amount
        for classes,combined_subject in special_groups:
            missing=[c for c in classes if delta.get((c,combined_subject),0)<0]
            if not missing:continue
            if combined_subject=='技家':
                # Each class in a joint lesson must retain its own period.
                for c in missing:
                    if any(delta.get((c,s),0)>0 for s in ('家庭','技術')):
                        consume_group((c,),('家庭','技術'),1)
                        delta[c,combined_subject]+=1
                continue
            concrete=('音楽','美術','総合') if combined_subject=='音美総' else ('家庭','技術')
            needed=2 if combined_subject=='音美総' else 1
            available=sum(max(0,delta.get((c,s),0)) for c in classes for s in concrete)
            if available<needed:continue
            consume_group(classes,concrete,needed)
            for c in missing:delta[c,combined_subject]+=1
        messages=[]
        for key in sorted(delta):
            c,subject=key;difference=delta[key];before=expected[key];now=actual[key]
            if difference<0:messages.append(f'{c} {subject}：授業不足（原本{before}コマ／現在{now}コマ）')
            elif difference>0:messages.append(f'{c} {subject}：授業過多（原本{before}コマ／現在{now}コマ）')
        return messages

    def full_teacher_days(self,pos,exclude_exempt=True):
        occupied=defaultdict(set)
        # Fixed meetings and other non-lesson entries occupy a period too.
        # Only a literal empty cell counts as a daily free period; slash marks do not. Empty absence-marked cells count as free.
        for teacher in self.data['teachers']:
            for slot,value in enumerate(teacher['cells']):
                if parse_cell(value)[0] in ('duty','unknown','blocked'):
                    occupied[teacher['id'],SLOTS[slot][0]].add(slot)
        for k,slot in pos.items():
            for teacher in self.lessons[k].teachers:occupied[teacher,SLOTS[slot][0]].add(slot)
        return {(t,d) for (t,d),slots in occupied.items() if len(slots)>=len(DAY_SLOTS[d])
                and (not exclude_exempt or (t,d) not in self.free_exempt_days)}

    def gap_required(self):
        return self.rules['daily_free']

    def required_free_days(self,pos):
        return self.full_teacher_days(pos) if self.rules['daily_free'] else set()

    def movement_allowed(self,lesson):
        if not self.rules['movement_same_grade']:return True
        requested={t for t,s in self.absent}
        if not requested:return True
        grades=self.data.get('teacher_grades',{})
        allowed={grades.get(t) for t in requested}-{None,'','未設定'}
        return all(t in requested or grades.get(t) in allowed for t in lesson.teachers)

    def hard_errors(self,pos):
        errors=[]
        for k in sorted(self.split_joint(pos)):
            if k!=self.joint_key[k]:continue
            members=self.joint_members[k];anchors={pos[j] for j in members if self.lessons[j].locked}
            reason='合同授業の固定位置が食い違っています' if len(anchors)>1 else '合同授業の担当者の時限が分かれています'
            errors.append(self.label(k)+'：'+reason)
        if self.rules['same_day_only']:
            errors.extend(f'{self.label(k)}：同じ曜日の条件に違反' for k,s in pos.items()
                          if SLOTS[s][0]!=SLOTS[self.day_reference[k]][0])
        errors.extend(f'{self.label(k)}：同じ学年の先生のみの条件に違反' for k,s in pos.items()
                      if s!=self.initial.get(k,s) and not self.movement_allowed(self.lessons[k]))
        if self.gap_required():
            errors.extend(f'{self.teachers[t]} {d}：空きコマが1つもありません'
                          for t,d in sorted(self.required_free_days(pos)))
        return errors

    def move_context(self):
        return (*self.occupancy(self.positions),self.science(self.positions),self.arts_rooms(self.positions))

    def compatible_destination(self,lesson,dest,occupancy):
        category=exchange_category(lesson.subject)
        for teacher in lesson.teachers:
            others=occupancy[teacher,dest]
            if category:
                if not others or any(exchange_category(self.lessons[k].subject)!=category for k in others):return False
            elif any(exchange_category(self.lessons[k].subject) for k in others):return False
        return True

    def valid_move(self,changes,enforce_gap=True,context=None):
        if not changes:return False
        occ,cls,pe,science,arts=context if context is not None else self.move_context()
        moved=set(changes)
        after=self.positions|changes
        if self.joint_sets and any(len({after[j] for j in self.joint_members[k]})>1 for k in changes):return False
        add_t=defaultdict(set);add_c=defaultdict(set);add_pe=defaultdict(set)
        add_sci=defaultdict(set);add_arts=defaultdict(set)
        for lid,dest in changes.items():
            if lid not in self.lessons or type(dest)!=int or not 0<=dest<len(SLOTS):return False
            l=self.lessons[lid]
            if l.locked or not self.movement_allowed(l):return False
            if not self.compatible_destination(l,dest,occ):return False
            if self.rules['same_day_only'] and SLOTS[dest][0]!=SLOTS[self.day_reference[lid]][0]:return False
            if self.rules['pe_limit'] and '10' in l.classes and l.subject=='保体' and self.pe_policy=='未設定':return False
            for t in l.teachers:
                if (t,dest) in self.blocked or (t,dest) in self.absent:return False
                add_t[t,dest].add(lid)
            for c in l.classes:add_c[c,dest].add(lid)
            for g in self.pe_grades(l):add_pe[g,dest].add(lid)
            if l.subject=='理科':add_sci[dest].add(lid)
            for room in self.rooms_used(l):add_arts[room,dest].add(lid)
        for base,added in ((occ,add_t),(cls,add_c)):
            if any((len((base[key]-moved)|ids) if base is occ else self.joint_count((base[key]-moved)|ids))>1 for key,ids in added.items()):return False
        if any(self.joint_count((pe[key]-moved)|ids)>self.pe_capacity.get(key,1) for key,ids in add_pe.items()):return False
        late=self.late_pe_violations(self.positions|changes) if any(self.lessons[k].subject=='保体' for k in changes) else {}
        if any(self.lessons[k].subject=='保体' and dest in late for k,dest in changes.items()):return False
        if self.rules['science_limit']:
            for dest,ids in add_sci.items():
                group=(science[dest]-moved)|ids
                if self.joint_count(group)>self.science_capacity.get(dest,3):return False
        if any(self.room_conflict(room,dest,(arts[room,dest]-moved)|ids) for (room,dest),ids in add_arts.items()):return False
        if self.rules['pe_limit'] and self.pe_policy=='未設定':
            for lid,dest in changes.items():
                if self.lessons[lid].subject=='保体' and ((pe['未設定',dest]-moved)|add_pe['未設定',dest]):return False
        if enforce_gap and self.gap_required() and self.required_free_days(self.positions|changes):return False
        return True

    def class_bundle_swaps(self,lid,classes=None):
        lesson=self.lessons[lid]
        if len(lesson.classes)<2:return []
        classes=self.occupancy(self.positions)[1] if classes is None else classes
        source=self.positions[lid];plans=[];wanted=set(lesson.classes)
        for target in range(len(SLOTS)):
            if target==source:continue
            ids=set().union(*(classes[c,target] for c in wanted))
            if not ids or any(self.lessons[k].locked or not set(self.lessons[k].classes)<=wanted for k in ids):continue
            if set().union(*(set(self.lessons[k].classes) for k in ids))!=wanted:continue
            plans.append({lid:target}|{k:source for k in ids})
        return plans

    def search(self,lid,three=True,cancel=None,deadline=None,enforce_gap=True):
        source=self.lessons[lid];s=self.positions[lid]
        context=self.move_context()
        def stopped():return (cancel is not None and cancel.is_set()) or (deadline is not None and time.monotonic()>=deadline)
        def valid(plan):
            expanded=self.expand_joint(plan)
            if not expanded:return False
            plan.clear();plan.update(expanded)
            return self.valid_move(plan,enforce_gap,context)
        if source.locked or not self.movement_allowed(source):return []
        pool=[l for l in self.lessons.values() if l.id!=lid and exchange_key(l)==exchange_key(source) and not l.locked and self.movement_allowed(l)]
        result=[]
        # Direct edits can leave a duplicated period and a vacant period.
        # Moving into that vacancy must not require a swap partner.
        for dest in range(len(SLOTS)):
            if stopped():return result
            plan={lid:dest}
            if dest!=s and valid(plan):result.append(plan)
        for other in pool:
            if stopped():return result
            q=self.positions[other.id]
            if q==s:continue
            plan={lid:q,other.id:s}
            if valid(plan):result.append(plan)
        for plan in self.class_bundle_swaps(lid,context[1]):
            if stopped():return result
            if valid(plan):result.append(plan)
        if three:
            for a,b in combinations(pool,2):
                if stopped():return result
                q,r=self.positions[a.id],self.positions[b.id]
                if len({s,q,r})<3:continue
                for plan in ({lid:q,a.id:r,b.id:s},{lid:r,b.id:q,a.id:s}):
                    if valid(plan):result.append(plan)
        return sorted(result,key=lambda p:(len(p),sum(len(self.lessons[x].teachers) for x in p),abs(p[lid]-s),tuple(p.values())))

    def search_linked(self,lid,max_moves=12,seconds=20,limit=80,cancel=None,enforce_gap=True,targets=None):
        """同じクラスの交換を他クラスにも連鎖させ、先生・教室の衝突を解消する。"""
        start=time.monotonic();nodes=0;cutoff=False;results=[];seen=set()
        if self.lessons[lid].locked or not self.movement_allowed(self.lessons[lid]):return [],{'nodes':0,'limited':False}
        pools=defaultdict(list)
        for k,l in self.lessons.items():
            if not l.locked and self.movement_allowed(l):pools[exchange_key(l)].append(k)
        base_t,base_c,base_pe=self.occupancy(self.positions)
        base_sci=self.science(self.positions)
        base_arts=self.arts_rooms(self.positions)
        context=(base_t,base_c,base_pe,base_sci,base_arts)
        def blockers(plan):
            moved=set(plan);add_t=defaultdict(set);add_c=defaultdict(set);add_pe=defaultdict(set);add_sci=defaultdict(set);add_arts=defaultdict(set)
            for k,s in plan.items():
                l=self.lessons[k]
                if l.locked or not self.movement_allowed(l):return None
                if not self.compatible_destination(l,s,base_t):return None
                if self.rules['same_day_only'] and SLOTS[s][0]!=SLOTS[self.day_reference[k]][0]:return None
                if self.rules['pe_limit'] and l.subject=='保体' and '10' in l.classes and self.pe_policy=='未設定':return None
                for t in l.teachers:
                    if (t,s) in self.blocked or (t,s) in self.absent:return None
                    add_t[t,s].add(k)
                for c in l.classes:add_c[c,s].add(k)
                for g in self.pe_grades(l):add_pe[g,s].add(k)
                if l.subject=='理科':add_sci[s].add(k)
                for room in self.rooms_used(l):add_arts[room,s].add(k)
            for k,s in plan.items():
                l=self.lessons[k]
                for t in l.teachers:
                    collision=((base_t[t,s]-moved)|add_t[t,s])-{k}
                    if collision:
                        if collision & moved:return None
                        return sorted(collision)
                for c in l.classes:
                    if self.joint_count((base_c[c,s]-moved)|add_c[c,s])>1:return None
            for k,s in plan.items():
                l=self.lessons[k]
                if self.rules['pe_limit'] and l.subject=='保体':
                    if self.pe_policy=='未設定' and ((base_pe['未設定',s]-moved)|add_pe['未設定',s]):return None
                    for g in self.pe_grades(l):
                        group=(base_pe[g,s]-moved)|add_pe[g,s]
                        if self.joint_count(group)>self.pe_capacity.get((g,s),1):
                            choices=group-moved
                            return sorted(choices) if choices else None
                if l.subject=='理科':
                    science=(base_sci[s]-moved)|add_sci[s]
                    if self.rules['science_limit'] and self.joint_count(science)>self.science_capacity.get(s,3):
                        choices=science-moved
                        return sorted(choices) if choices else None
                for room in self.rooms_used(l):
                    arts=(base_arts[room,s]-moved)|add_arts[room,s]
                    if self.room_conflict(room,s,arts):
                        choices=arts-moved
                        return sorted(choices) if choices else None
            late=self.late_pe_violations(self.positions|plan) if any(self.lessons[k].subject=='保体' for k in plan) else {}
            for slot,ids in late.items():
                if any(self.lessons[k].subject=='保体' and s==slot for k,s in plan.items()):
                    return sorted(ids-moved) or None
            if enforce_gap and self.gap_required():
                full=self.required_free_days(self.positions|plan)
                if full:
                    choices=sorted(k for k,l in self.lessons.items() if k not in moved and not l.locked
                                   and any((t,SLOTS[self.positions[k]][0]) in full for t in l.teachers))
                    return choices or None
            return []
        def walk(plan):
            nonlocal nodes,cutoff
            if time.monotonic()-start>=seconds or len(results)>=limit or (cancel is not None and cancel.is_set()):
                cutoff=True;return
            plan=self.expand_joint(plan)
            if not plan:return
            signature=tuple(sorted(plan.items()))
            if signature in seen:return
            seen.add(signature);nodes+=1
            conflict=blockers(plan)
            if conflict is None:return
            if not conflict:
                if self.valid_move(plan,enforce_gap,context):results.append(plan)
                return
            if len(plan)>=max_moves:return
            for blocked in conflict:
                if blocked in plan or self.lessons[blocked].locked:continue
                slot=self.positions[blocked]
                for target in range(len(SLOTS)):
                    if target==slot:continue
                    if any(base_c[c,target]-set(plan)-self.joint_members[blocked] for c in self.lessons[blocked].classes):continue
                    walk(plan|{blocked:target})
                    if cutoff:return
                if len(plan)+2>max_moves:continue
                for other in pools[exchange_key(self.lessons[blocked])]:
                    if other==blocked or other in plan:continue
                    target=self.positions[other]
                    if target==slot:continue
                    walk(plan|{blocked:target,other:slot})
                    if cutoff:return
        # Iterative depth keeps fewer changes ahead of long chains.
        requested=max_moves
        for bound in range(4,requested+1,2):
            max_moves=bound;seen.clear()
            for plan in self.class_bundle_swaps(lid,base_c):
                if targets is not None and plan[lid] not in targets:continue
                walk(plan)
                if cutoff:break
            for target in range(len(SLOTS)):
                if cutoff:break
                if target==self.positions[lid]:continue
                if targets is not None and target not in targets:continue
                if any(base_c[c,target]-self.joint_members[lid] for c in self.lessons[lid].classes):continue
                walk({lid:target})
                if cutoff:break
            for other in pools[exchange_key(self.lessons[lid])]:
                if cutoff:break
                if other==lid or self.positions[other]==self.positions[lid]:continue
                if targets is not None and self.positions[other] not in targets:continue
                walk({lid:self.positions[other],other:self.positions[lid]})
                if cutoff:break
            if results or cutoff:break
        unique={tuple(sorted(p.items())):p for p in results}
        result=sorted(unique.values(),key=lambda p:(len(p),sum(len(self.lessons[k].teachers) for k in p),abs(p[lid]-self.positions[lid])))
        return result,{'nodes':nodes,'limited':cutoff,'max_moves':max_moves}

    def apply(self,changes):
        if not self.valid_move(changes):raise ValueError('条件が変わりました。候補を検索し直してください。')
        self.positions.update(changes)

    def unresolved(self,pos=None):
        pos=self.positions if pos is None else pos
        return [k for k,l in self.lessons.items() if any((t,pos[k]) in self.absent for t in l.teachers)]

    def pending_lessons(self,pos):
        pending=set(self.unresolved(pos))|self.split_joint(pos)
        if self.gap_required():
            full=self.required_free_days(pos)
            pending.update(k for k,l in self.lessons.items() if any((t,SLOTS[pos[k]][0]) in full for t in l.teachers))
        if self.rules['same_day_only']:
            pending.update(k for k,s in pos.items() if SLOTS[s][0]!=SLOTS[self.day_reference[k]][0])
        teachers,classes,pe=self.occupancy(pos)
        for buckets in (teachers,classes):
            for ids in buckets.values():
                if (len(ids) if buckets is teachers else self.joint_count(ids))>1:pending.update(ids)
        for key,ids in pe.items():
            if self.joint_count(ids)>self.pe_capacity.get(key,1):pending.update(ids)
        for ids in self.late_pe_violations(pos).values():pending.update(ids)
        for (teacher,slot),ids in teachers.items():
            if (teacher,slot) in self.blocked:pending.update(ids)
        for slot,ids in self.science(pos).items():
            if self.rules['science_limit'] and self.joint_count(ids)>self.science_capacity.get(slot,3):pending.update(ids)
        for (room,slot),ids in self.arts_rooms(pos).items():
            if self.room_conflict(room,slot,ids):pending.update(ids)
        return sorted(pending)

    def blocker_diagnostics(self,pos):
        teachers,classes,pe=self.occupancy(pos);science=self.science(pos);arts=self.arts_rooms(pos)
        lines=[e for e in self.hard_errors(pos) if '合同授業' in e];combined_involved=False
        for lid in self.pending_lessons(pos):
            lesson=self.lessons[lid];source=pos[lid]
            combined_involved|=lesson.subject=='音美総'
            if lesson.locked:
                lines.append(f'{SLOTS[source]} {self.label(lid)}：固定条件が障害です。')
                continue
            reasons=defaultdict(int)
            for dest in range(len(SLOTS)):
                if dest==source:continue
                found=set()
                for t in lesson.teachers:
                    if (t,dest) in self.absent:found.add(f'{self.teachers[t]}の不在')
                    if (t,dest) in self.blocked:found.add(f'{self.teachers[t]}の固定・勤務不可')
                    occupied=teachers[t,dest]-{lid}
                    if occupied:
                        found.add(f'{self.teachers[t]}の別授業')
                        combined_involved|=any(self.lessons[k].subject=='音美総' for k in occupied)
                for c in lesson.classes:
                    occupied=classes[c,dest]-{lid}
                    if occupied:
                        found.add(f'{c}の別授業')
                        combined_involved|=any(self.lessons[k].subject=='音美総' for k in occupied)
                for g in self.pe_grades(lesson):
                    if len(pe[g,dest]-{lid})>=self.pe_capacity.get((g,dest),1):found.add(f'体育{g}年の重複')
                if self.rules['science_limit'] and lesson.subject=='理科' and len(science[dest]-{lid})>=self.science_capacity.get(dest,3):found.add('理科室の上限')
                for room in self.rooms_used(lesson):
                    if len(arts[room,dest]-{lid})>=self.room_capacity.get((room,dest),1):found.add(f'{room}の重複')
                if self.rules['pe_no_late'] and lesson.subject=='保体' and SLOTS[dest][-1] in '56' and len(self.late_pe(pos)[dest]-{lid})>=self.late_pe_capacity.get(dest,0):found.add('保体の５・６限制限')
                for reason in found:reasons[reason]+=1
            top=sorted(reasons.items(),key=lambda x:(-x[1],x[0]))[:4]
            detail='、'.join(f'{reason}（{count}コマ）' for reason,count in top)
            lines.append(f'{SLOTS[source]} {self.label(lid)}：{detail or "複数授業の連鎖交換が必要です"}')
        if combined_involved:
            lines.append('対処案：「音美総」を、その週の実際のクラス・教科（音楽・美術・総合）に具体的に入力してみてください。')
        return lines

    def changed_cells(self,pos=None):
        """Compare lesson identities, including identical-looking lessons exchanging slots."""
        pos=self.positions if pos is None else pos
        if self.data.get('weekly_baseline'):
            before=self.baseline_rows();after=self.rows(pos,mark_fixed=False)
            return {(t,s) for t in self.teachers for s in range(len(SLOTS)) if self.cell_signature(before[t][s])!=self.cell_signature(after[t][s])}
        before=defaultdict(set);after=defaultdict(set)
        for k,l in self.lessons.items():
            for t in l.teachers:before[t,l.origin].add(k);after[t,pos[k]].add(k)
        return {(t,s) for t in self.teachers for s in range(len(SLOTS)) if before[t,s]!=after[t,s]}

    @staticmethod
    def cell_signature(value):
        kind,classes,subject,_=parse_cell(value)
        return kind,classes,subject

    def baseline_rows(self):
        base=self.data.get('weekly_baseline')
        return {t['id']:list(t['cells']) for t in base['teachers']} if base else self.rows(self.initial,False)

    def preference_metrics(self,pos,baseline=None):
        baseline=self.positions if baseline is None else baseline
        days=defaultdict(set);people=set();cross_day=0
        for k,slot in pos.items():
            l=self.lessons[k];day=SLOTS[slot][0]
            for teacher in l.teachers:days[teacher,day].add(slot)
            if slot!=baseline[k]:
                people.update(l.teachers)
                if day!=SLOTS[baseline[k]][0]:cross_day+=1
        return {'full_days':sum(len(slots)==(5 if day=='木' else 6) for (teacher,day),slots in days.items()),'people':len(people),'same_day':cross_day}

    def preference_score(self,pos,baseline=None):
        baseline=self.positions if baseline is None else baseline
        moved=[k for k,s in pos.items() if s!=baseline[k]]
        return (len(moved),len({t for k in moved for t in self.lessons[k].teachers}))

    def candidate_rank(self,pos):
        cells=self.changed_cells(pos)
        return len(cells),len({t for t,s in cells})

    def cell_violation_reasons(self,teacher,slot,pos=None):
        pos=self.positions if pos is None else pos
        teachers,classes,pe=self.occupancy(pos);science=self.science(pos);rooms=self.arts_rooms(pos)
        reasons=[]
        ids=teachers[teacher,slot]
        full=self.required_free_days(pos) if self.gap_required() else set()
        late=self.late_pe_violations(pos)
        for k in ids:
            l=self.lessons[k]
            if any((t,slot) in self.absent for t in l.teachers):reasons.append('空き指定に授業あり')
            if any((t,slot) in self.blocked for t in l.teachers):reasons.append('勤務不可・固定予定と重複')
            if any(len(teachers[t,slot])>1 for t in l.teachers):reasons.append('先生の授業重複')
            if any(self.joint_count(classes[cl,slot])>1 for cl in l.classes):reasons.append('クラスの授業重複')
            if any(self.joint_count(pe[g,slot])>self.pe_capacity.get((g,slot),1) for g in self.pe_grades(l)):reasons.append('保体の同時授業数の上限超過')
            if l.subject=='理科' and self.rules['science_limit'] and self.joint_count(science[slot])>self.science_capacity.get(slot,3):reasons.append('理科の同時授業数の上限超過')
            for room in self.rooms_used(l):
                if self.room_conflict(room,slot,rooms[room,slot]):reasons.append(room+'の同時授業数の上限超過')
            if k in late.get(slot,set()):reasons.append('保体の５・６限制限')
            if any((t,SLOTS[slot][0]) in full for t in l.teachers):reasons.append('空きコマ１以上')
            if self.rules['same_day_only'] and SLOTS[slot][0]!=SLOTS[self.day_reference[k]][0]:reasons.append('同じ曜日の中で変更')
        split=self.split_joint(pos)
        if any(k in split and teacher in l.teachers and pos[k]==slot for k,l in self.lessons.items()):reasons.append('合同授業の担当者の時限不一致')
        if any(l.locked and pos[k]!=l.origin and teacher in l.teachers and slot in (l.origin,pos[k]) for k,l in self.lessons.items()):reasons.append('固定授業の移動')
        if parse_cell(next(t for t in self.data['teachers'] if t['id']==teacher)['cells'][slot])[0]=='unknown':reasons.append('内容を判定できない予定')
        return list(dict.fromkeys(reasons))

    def violation_cells(self,pos):
        cells={(t,pos[k]) for k in self.pending_lessons(pos) for t in self.lessons[k].teachers}
        for k,l in self.lessons.items():
            if l.locked and pos[k]!=l.origin:
                cells.update((t,s) for t in l.teachers for s in (l.origin,pos[k]))
        for teacher in self.data['teachers']:
            for slot,value in enumerate(teacher['cells']):
                if parse_cell(value)[0]=='unknown':cells.add((teacher['id'],slot))
        return cells

    def solve_absences(self,seconds=120,cancel=None,profile=None,progress=None):
        from selfstudy import reassignable_records
        if self.study_requests or reassignable_records(self):
            from selfstudy import solve
            return solve(self,seconds,cancel,profile,progress)
        return self._solve_regular(seconds,cancel,profile,progress)

    def _solve_regular(self,seconds=120,cancel=None,profile=None,progress=None):
        """Keep the best feasible complete schedule found within the search budget."""
        work=Model(copy.deepcopy(self.saved()));start=time.monotonic();deadline=start+seconds
        from search_settings import PROFILES
        profile=profile or PROFILES['standard']
        work.day_reference=dict(self.day_reference)
        original=dict(work.positions);best=dict(original);best_remaining=len(work.pending_lessons(original))
        phase_deadline=deadline;depth_limit=80;last_report=0.0
        winner=None;winner_score=None;seen=set();nodes=0;limited=False;solutions=0;complete_seen=set();top_candidates=[]
        def stopped():return time.monotonic()>=phase_deadline or (cancel is not None and cancel.is_set())
        def score(pos):return work.preference_score(pos,original)
        def walk(pos,depth=0):
            nonlocal best,best_remaining,nodes,limited,winner,winner_score,solutions,last_report
            if stopped():limited=True;return
            signature=tuple(sorted((k,s) for k,s in pos.items() if s!=original[k]))
            if signature in seen:return
            seen.add(signature);nodes+=1;work.positions=pos
            pending=work.pending_lessons(pos);remaining=len(pending)
            if progress is not None and time.monotonic()-last_report>=0.3:
                last_report=time.monotonic();progress({"nodes":nodes,"solutions":solutions,"remaining":0 if winner is not None else best_remaining,"elapsed":last_report-start})
            if remaining<best_remaining or (remaining==best_remaining and score(pos)<score(best)):
                best=dict(pos);best_remaining=remaining
            if not pending:
                if not work.errors(pos):
                    cells=work.changed_cells(pos);rows=work.rows(pos,mark_fixed=False)
                    visible=tuple((t,s,work.cell_signature(rows[t][s])) for t,s in sorted(cells))
                    if visible not in complete_seen:
                        complete_seen.add(visible);solutions+=1
                        value=(len(cells),len({t for t,s in cells}))
                        top_candidates.append({'positions':dict(pos),'changed_cell_count':value[0],'teacher_count':value[1],
                            'changes':{k:s for k,s in pos.items() if s!=original[k]}})
                        top_candidates.sort(key=lambda c:(c['changed_cell_count'],c['teacher_count'],tuple(sorted(c['changes'].items()))))
                        del top_candidates[10:]
                        winner=dict(top_candidates[0]['positions']);winner_score=value
                        if progress is not None and (solutions==1 or time.monotonic()-last_report>=0.1):
                            last_report=time.monotonic();progress({'nodes':nodes,'solutions':solutions,'remaining':0,'elapsed':last_report-start})
                return
            if depth>=depth_limit:limited=True;return
            movable=[k for k in pending if not work.lessons[k].locked]
            absent_teachers={t for t,s in work.absent}
            movable.sort(key=lambda k:(-sum(t in absent_teachers for t in work.lessons[k].teachers),pos[k],k))
            for k in movable:
                if stopped():limited=True;return
                work.positions=pos
                plans=work.search(k,True,cancel=cancel,deadline=phase_deadline,enforce_gap=False)
                plans=sorted(plans,key=lambda plan:(len(work.pending_lessons(pos|plan)),score(pos|plan)))[:profile['normal_limit']]
                for plan in plans:
                    walk(pos|plan,depth+1)
                    if stopped():limited=True;return
                work.positions=pos
                linked,info=work.search_linked(k,max_moves=profile['moves'],seconds=max(.001,min(profile['linked_seconds'],phase_deadline-time.monotonic())),limit=profile['linked_limit'],cancel=cancel,enforce_gap=False)
                limited|=info['limited'];known={tuple(sorted(plan.items())) for plan in plans}
                for plan in sorted(linked,key=lambda plan:score(pos|plan)):
                    if tuple(sorted(plan.items())) not in known:walk(pos|plan,depth+1)
                    if stopped():limited=True;return
        # Short paths get a fair share before deep branches; retain the best result across passes.
        for depth_limit,fraction in ((2,.12),(4,.30),(8,.55),(16,.78),(80,1.0)):
            if time.monotonic()>=deadline or (cancel is not None and cancel.is_set()):break
            phase_deadline=start+seconds*fraction;seen.clear();walk(original)
        positions=winner if winner is not None else best
        unresolved=work.unresolved(positions);issues=work.errors(positions,False)
        details=[{'lesson':k,'slot':positions[k],'fixed':work.lessons[k].locked,
                  'reason':'固定授業のため移動できません' if work.lessons[k].locked else '検索範囲内で移動先を確保できませんでした'} for k in unresolved]
        result={'positions':positions,'complete':not unresolved and not issues,'unresolved':details,'issues':issues,
                'limited':limited or stopped(),'nodes':nodes,'seconds':round(time.monotonic()-start,2),'solutions_compared':solutions,
                'priority_metrics':work.preference_metrics(positions,original),'priorities':list(work.priorities),'priority_enabled':sorted(work.priority_enabled),
                'changes':{k:s for k,s in positions.items() if s!=original[k]},'diagnostics':work.blocker_diagnostics(positions)}
        result['candidates']=[dict(c,complete=True,unresolved=[],issues=[],diagnostics=[]) for c in top_candidates]
        result['changed_cell_count'],result['teacher_count']=work.candidate_rank(positions)
        if progress is not None:progress({'nodes':nodes,'solutions':solutions,'remaining':len(unresolved),'elapsed':time.monotonic()-start})
        return result

    def apply_batch(self,result):
        positions=result.get('positions',{})
        if set(positions)!=set(self.positions) or not result.get('complete'):
            raise ValueError('全件を解消した時間割だけ確定できます。')
        if any(type(s)!=int or not 0<=s<len(SLOTS) for s in positions.values()):raise ValueError('授業位置が不正です。')
        if self.errors(positions):raise ValueError('条件が変わりました。全件を再検索してください。')
        changes={k:s for k,s in positions.items() if s!=self.positions[k]}
        if changes and not self.valid_move(changes):raise ValueError('変更内容が現在の条件と一致しません。')
        self.positions=dict(positions)

    def label(self,lid):
        l=self.lessons[lid]
        return f"{'・'.join(l.classes)} {l.subject}（{'・'.join(self.teachers[t] for t in l.teachers)}）"

    def rows(self,pos=None,mark_fixed=True):
        pos=self.positions if pos is None else pos
        rows={t['id']:list(t['cells']) for t in self.data['teachers']}
        for l in self.lessons.values():
            for t in l.teachers:rows[t][l.origin]=''
        for lid,s in pos.items():
            l=self.lessons[lid]
            if not l.classes:key=''
            elif '10' in l.classes:key='10・11・12'
            else:key=l.classes[0].split('-')[0]+'-'+'.'.join(c.split('-')[1] for c in l.classes)
            explicit=any(str(t['cells'][l.origin]).strip().startswith('!') for t in self.data['teachers'] if t['id'] in l.teachers)
            value=('!' if l.locked and (mark_fixed or explicit) else '')+(key+' ' if key else '')+l.subject
            for t in l.teachers:rows[t][s]=value
        return rows

    def reference_differences(self):
        lookup=defaultdict(set)
        for l in self.lessons.values():
            for c in l.classes:lookup[c,l.origin].add(l.subject)
        differences=[]
        for key,subjects in self.data.get('class_reference',{}).items():
            classes=('10','11','12') if key=='10・11・12' else (key,)
            for s,expected in enumerate(subjects):
                if expected in FIXED_SUBJECTS or expected in ('','/','／'):continue
                actual=lookup[classes[0],s]
                if actual!={expected}:differences.append(f"{key} {SLOTS[s]}：クラス別={expected}／先生別={','.join(sorted(actual)) or 'なし'}")
        return differences

    def saved(self):
        return self.data|{'joint_links':self.joint_records(),'positions':self.positions,'absent':sorted(self.absent),'manual_fixed':sorted(self.manual_fixed),'day_reference':dict(self.day_reference),'pe_policy':self.pe_policy,'conditions':dict(self.rules),'priorities':list(self.priorities),'priority_enabled':{k:k in self.priority_enabled for k in PRIORITIES}}

