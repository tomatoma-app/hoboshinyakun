"""Excel is the source of truth; settings never replace worksheet contents."""
import copy, hashlib, io, json
from pathlib import Path
from engine import Model, SLOTS, parse_cell, duty_rule, fixed_by_conditions, exchange_category, is_study_subject

BASIC='原本(さわらない)'
BASELINE=BASIC
CURRENT='変更はここに！'
SETTINGS='アプリ設定'
TABLES=(BASIC,CURRENT)
LEGACY={BASIC:'基本時間割',CURRENT:'今週の変更時間割'}
# Baseline used by releases before workbook fingerprints were saved.
LEGACY_BASELINE_STAMP='aeecf8b3b1366fe63b9a9a64902454fc61adfe92a0af796254e028ae1c27f1c2'

def baseline_stamp(table):
    return hashlib.sha256(json.dumps(table['teachers'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def template_rows(model,positions=None):
    positions=model.positions if positions is None else positions
    original=model.data['weekly_template']['rows'];rows=copy.deepcopy(original)
    indices={t['id']:i for i,t in enumerate(model.data['teachers'])}
    for lesson in model.lessons.values():
        for t in lesson.teachers:
            i=indices[t];rows[2*i][lesson.origin+1]=rows[2*i+1][lesson.origin+1]=None
    for lid,dest in positions.items():
        l=model.lessons[lid]
        for t in l.teachers:
            i=indices[t]
            if lid.startswith('@study:'):
                rows[2*i][dest+1]=(l.classes[0].split('-')[0]+'-'+'.'.join(c.split('-')[1] for c in l.classes)
                                      if all('-' in c for c in l.classes) else '・'.join(l.classes))
                rows[2*i+1][dest+1]=l.subject
                continue
            for offset in (0,1):rows[2*i+offset][dest+1]=original[2*i+offset][l.origin+1]
    return rows

def current_table(model,positions=None):
    # Rebase lesson identities after manual edits/import, retaining the weekly baseline separately.
    rows=model.rows(model.positions if positions is None else positions,mark_fixed=False)
    return {'teachers':[dict(t,cells=rows[t['id']]) for t in model.data['teachers']],
            'weekly_template':dict(copy.deepcopy(model.data['weekly_template']),rows=template_rows(model,positions))}

def initialize(data):
    if 'weekly_baseline' not in data:
        table={k:copy.deepcopy(data[k]) for k in ('teachers','weekly_template')}
        data['basic_table']=copy.deepcopy(table);data['weekly_baseline']=copy.deepcopy(table)
        data['cycle_map']=list(range(len(SLOTS)))
    return data

def settings(model):
    from absence_borders import backups
    return {'version':3,'room_limits':dict(model.room_limits),'study_settings':model.data.get('study_settings',{}),'teacher_grades':model.data.get('teacher_grades',{}),'study_requests':model.data.get('study_requests',[]),'study_records':model.data.get('study_records',[]),'baseline_stamp':baseline_stamp(model.data['basic_table']),'joint_links':model.joint_records(model.positions),'search_mode':model.data.get('search_mode','standard'),'free_exempt_days':sorted(model.free_exempt_days),'conditions':dict(model.rules),'priorities':list(model.priorities),'priority_enabled':{k:k in model.priority_enabled for k in __import__('engine').PRIORITIES},
            'absent':sorted(model.absent),'manual_fixed':sorted(model.manual_fixed),'absence_borders_version':1,'absence_border_backups':backups(model),
            'pe_policy':model.pe_policy,'cycle_map':list(model.data.get('cycle_map',range(len(SLOTS)))),
            'baseline_class_reference':model.data.get('baseline_class_reference',{}),
            'basic_class_reference':model.data.get('basic_class_reference',{})}

def load_shared(path,conditions=None):
    import openpyxl
    from weekly_excel import read_table, norm
    path=Path(path);raw=path.read_bytes()
    wb=openpyxl.load_workbook(io.BytesIO(raw),data_only=False)
    try:
        resolved={name:(name if name in wb.sheetnames else LEGACY[name] if LEGACY[name] in wb.sheetnames else None) for name in TABLES}
        shared=any(resolved.values())
        if shared and not all(resolved.values()):raise ValueError('「変更はここに！」と「原本(さわらない)」の2シートをそろえてください。')
        meta={}
        if SETTINGS in wb.sheetnames:
            sh=wb[SETTINGS]
            try:
                meta=json.loads(''.join(str(sh.cell(r,1).value or '') for r in range(4,sh.max_row+1)))
                if meta.get('version')!=3:raise ValueError('設定のバージョンが違います。')
            except Exception as e:raise ValueError('アプリ設定シートを読み込めません。設定を削除せず、元のファイルを確認してください。') from e
        name=resolved[CURRENT] if shared else '時間割'
        if name not in wb.sheetnames:raise ValueError('「時間割」または共有形式の3シートが必要です。')
        basic=read_table(wb[resolved[BASIC]]) if shared else read_table(wb[name])
        grade_sheet=wb[resolved[BASIC]] if shared else wb[name]
        import re
        teacher_grades={}
        for i,t in enumerate(basic['teachers']):
            value=norm(grade_sheet.cell(4+2*i,3).value)
            value=re.sub(r'[年学級組\s]','',value)
            grade={'1':'1','2':'2','3':'3','特支':'特別支援','特別支援':'特別支援'}.get(value,'未設定')
            teacher_grades[t['id']]=grade
        baseline_updated=shared and meta.get('baseline_stamp',LEGACY_BASELINE_STAMP)!=baseline_stamp(basic)
        if baseline_updated:
            # A new original starts a new schedule. Never carry per-cell state across originals.
            for key in ('absent','manual_fixed','joint_links','study_requests','study_records','free_exempt_days','baseline_class_reference','basic_class_reference','cycle_map'):
                meta.pop(key,None)
        table=copy.deepcopy(basic) if baseline_updated else read_table(wb[name])
        legacy_table=False
        reference={}
        if 'クラス別' in wb.sheetnames:
            import re
            cs=wb['クラス別']
            for r in range(4,min(cs.max_row,200)+1):
                c=norm(cs.cell(r,4).value).replace('組','')
                if re.fullmatch(r'[123]-[0-9]+|10・11・12',c):
                    values=[norm(cs.cell(r,col).value) for col in range(5,34)]
                    reference[c]=values
        if baseline_updated:reference={}
        def migrate_pairs(values):
            return [[t,s+1 if s>=23 else s] for t,s in values]
        def migrate_reference(value):
            result={}
            for c,row in (value or {}).items():
                row=list(row)
                if len(row)==29:row.insert(23,'／')
                result[c]=row
            return result
        saved_mapping=None
        mapping=list(range(len(SLOTS)))
        def map_table(source,mapping):
            result=copy.deepcopy(source)
            for old,new in zip(source['teachers'],result['teachers']):new['cells']=[old['cells'][s] for s in mapping]
            raw=source['weekly_template']['rows']
            result['weekly_template']['rows']=[[row[0]]+[row[s+1] for s in mapping]+[row[-1]] for row in raw]
            blocks={tuple(x) for x in source['weekly_template']['blocked']}
            result['weekly_template']['blocked']=[[i,j] for i in range(49) for j,s in enumerate(mapping) if (i,s) in blocks]
            result['weekly_template']['gray']=[i for i,t in enumerate(result['teachers']) if all(v=='/' for v in t['cells'])]
            return result
        base=copy.deepcopy(basic)
        for other in (base,basic):
            if [(t['id'],t['name']) for t in other['teachers']]!=[(t['id'],t['name']) for t in table['teachers']]:raise ValueError('3シートの先生名・並び順をそろえてください。')
        saved_absent=meta.get('absent',[]);saved_fixed=meta.get('manual_fixed',[])
        # A baseline change invalidates saved coordinates, not marks in today's worksheet.
        from absence_borders import detected
        outlined=detected(wb[name],table['teachers'],len(SLOTS))
        saved_absent=sorted(set(outlined) | (set() if baseline_updated or meta.get('absence_borders_version') else {tuple(x) for x in saved_absent}))
        data=table|{'rules_version':3,'title':str(wb[name]['D1'].value or path.stem),
             'source':path.name,'source_path':str(path.resolve()),'source_hash':hashlib.sha256(raw).hexdigest(),
             'room_limits':meta.get('room_limits',{}),'study_settings':meta.get('study_settings',{}),'teacher_grades':teacher_grades,'study_requests':meta.get('study_requests',[]),'study_records':meta.get('study_records',[]),
             'weekly_baseline':base,'basic_table':basic,'shared_format':shared,'baseline_updated':baseline_updated,
             'conditions':meta.get('conditions',conditions or {}),'priorities':meta.get('priorities',list(__import__('engine').PRIORITIES)),'priority_enabled':meta.get('priority_enabled',{k:True for k in __import__('engine').PRIORITIES}),
             'search_mode':meta.get('search_mode','standard'),'free_exempt_days':meta.get('free_exempt_days'),'absent':saved_absent,'manual_fixed':saved_fixed,'pe_policy':meta.get('pe_policy','未設定'),
             'cycle_map':mapping,'joint_links':meta.get('joint_links',[]),
             'baseline_class_reference':migrate_reference(meta.get('baseline_class_reference',reference)),
             'basic_class_reference':migrate_reference(meta.get('basic_class_reference',reference)),'class_reference':{},'history':[]}
        model=Model(data)
        # Import marks only on editable cells under the effective startup conditions.
        rows=model.rows(mark_fixed=False)
        excluded={cell for cell in outlined if cell in model.manual_fixed or cell in model.blocked
                  or fixed_by_conditions(*parse_cell(rows[cell[0]][cell[1]])[1:3],model.rules)}
        if excluded:
            model.absent.difference_update(excluded)
            data['absent']=sorted(model.absent)
        data['history']=difference_history(model)
        return data,shared
    finally:wb.close()

def difference_history(model):
    before=model.baseline_rows();after=model.rows(mark_fixed=False)
    lines=[f'{model.teachers[t]} {SLOTS[s]}　{before[t][s].lstrip("!") or "空き"} → {after[t][s].lstrip("!") or "空き"}' for t,s in sorted(model.changed_cells())]
    return [{'text':'「原本(さわらない)」との差分（Excelの現在の内容）\n'+'\n'.join(lines)}] if lines else []

def rebase(model):
    data=copy.deepcopy(model.saved());data.update(current_table(model));data.pop('positions',None);data.pop('day_reference',None)
    data['joint_links']=model.joint_records(model.positions)
    return data

def set_cycles(model,mapping):
    if len(mapping)!=len(SLOTS) or any(type(x)!=int or x not in range(len(SLOTS)) for x in mapping):raise ValueError(f'サイクルを{len(SLOTS)}コマ指定してください。')
    data=copy.deepcopy(model.saved());basic=data['basic_table'];table=copy.deepcopy(basic)
    for source,target in zip(basic['teachers'],table['teachers']):target['cells']=[source['cells'][s] for s in mapping]
    raw=basic['weekly_template']['rows'];table['weekly_template']['rows']=[[row[0]]+[row[s+1] for s in mapping]+[row[-1]] for row in raw]
    blocks={tuple(x) for x in basic['weekly_template']['blocked']}
    table['weekly_template']['blocked']=[[i,j] for i in range(49) for j,s in enumerate(mapping) if (i,s) in blocks]
    data.update(copy.deepcopy(table));data['weekly_baseline']=copy.deepcopy(table);data['cycle_map']=list(mapping)
    data['baseline_class_reference']={c:[row[s] for s in mapping] for c,row in data.get('basic_class_reference',{}).items()}
    data.update(absent=[],manual_fixed=[],history=[],class_reference={},joint_links=[],study_requests=[],study_records=[]);data.pop('positions',None)
    return Model(data)

def protected_unavailable(model,cells):
    if model.rules['allow_unavailable_edit']:return False
    rows=model.rows(mark_fixed=False)
    return any(parse_cell(rows[t][s])[0]=='blocked' for t,s in cells)

def protected_condition_fixed(model,cells):
    rows=model.rows(mark_fixed=False)
    return any(fixed_by_conditions(parse_cell(rows[t][s])[1],parse_cell(rows[t][s])[2],model.rules) for t,s in cells)

def protected_replacement(model,cells):
    return protected_unavailable(model,cells) or protected_condition_fixed(model,cells)

def swap_details(model,cells):
    cells=sorted(set(cells))
    if len(cells)!=2:return None
    if any(t not in model.teachers or type(s)!=int or not 0<=s<len(SLOTS) for t,s in cells):return None
    if protected_replacement(model,cells):return None
    first,second=cells;rows=model.rows(mark_fixed=False)
    parsed=[parse_cell(rows[t][slot]) for t,slot in cells]
    if first[0]==second[0]:
        categories=[exchange_category(p[2]) for p in parsed]
        if any(categories) and categories[0]!=categories[1]:return None
    else:
        if first[1]!=second[1]:return None
        if not any(exchange_category(p[2]) or is_study_subject(p[2]) for p in parsed):return None
    if not any(p[0]=='lesson' or (p[0]=='duty' and duty_rule(p[2]) is not None) for p in parsed):return None
    shared=[model.label(k) for k,l in model.lessons.items()
            if any((t,model.positions[k]) in cells for t in l.teachers)
            and (len(l.teachers)>1 or len(model.joint_members[k])>1)]
    return first,second,shared

def swap_cells(model,cells):
    details=swap_details(model,cells)
    if details is None:raise ValueError('入れ替え可能な2コマを選択してください。')
    first,second,shared=details
    data=rebase(model);mapping={first:second,second:first}
    indices={t['id']:i for i,t in enumerate(data['teachers'])}
    for record in data.get('study_records',[]):
        record['teacher'],record['slot']=mapping.get((record['teacher'],record['slot']),(record['teacher'],record['slot']))
    for record in data.get('joint_links',[]):
        record['cells']=[mapping.get(tuple(cell),tuple(cell)) for cell in record['cells']]
    (ta,a),(tb,b)=first,second;ia,ib=indices[ta],indices[tb]
    va,vb=data['teachers'][ia]['cells'],data['teachers'][ib]['cells']
    va[a],vb[b]=vb[b],va[a]
    for offset in (0,1):
        ra,rb=data['weekly_template']['rows'][2*ia+offset],data['weekly_template']['rows'][2*ib+offset]
        ra[a+1],rb[b+1]=rb[b+1],ra[a+1]
    data['weekly_template']['blocked']=[(i,s) for i,t in enumerate(data['teachers'])
        for s,v in enumerate(t['cells']) if parse_cell(v)[0]=='blocked']
    data['weekly_template']['gray']=[i for i,t in enumerate(data['teachers'])
        if all(parse_cell(value)[0]=='blocked' for value in t['cells'])]
    # Assignment follows the new teacher; absence and fixed marks stay on their cells.
    result=Model(data)
    result.data['history']=difference_history(result)
    return result,shared


BULK_ACTIONS={'fixed','unfixed','delete','empty','allow','study'}

def bulk_edit_targets(model,cells,action):
    cells=set(cells)
    if action not in BULK_ACTIONS:return cells
    rows=model.rows(mark_fixed=False);targets=set()
    for t,s in cells:
        kind,classes,subject,_=parse_cell(rows[t][s])
        if kind=='blocked' and not model.rules['allow_unavailable_edit']:continue
        if fixed_by_conditions(classes,subject,model.rules):continue
        if action=='fixed' and (t,s) in model.absent:continue
        if action=='study' and (kind not in ('free','lesson') or (t,s) in model.manual_fixed):continue
        targets.add((t,s))
    return targets

def edit_cells(model,cells,action,classes=None,subject=None):
    cells=set(cells)
    if not cells:return model
    if any(t not in model.teachers or s not in range(len(SLOTS)) for t,s in cells):raise ValueError('選択範囲が不正です。')
    cells=bulk_edit_targets(model,cells,action)
    if not cells:return model
    if protected_unavailable(model,cells):raise ValueError('勤務不可の編集は詳細条件で許可してください。')
    if action=='lesson' and protected_condition_fixed(model,cells):raise ValueError('詳細条件の該当する固定チェックを外してください。')
    if action=='study':
        from selfstudy import request_study
        return request_study(model,cells)
    data=rebase(model);absent=set(model.absent);fixed=set(model.manual_fixed)
    if action in ('delete','lesson'):
        data['study_records']=[r for r in data.get('study_records',[]) if (r['teacher'],r['slot']) not in cells]
    if action in ('allow','empty','delete','lesson'):
        data['study_requests']=sorted({tuple(x) for x in data.get('study_requests',[])}-cells)
    if action=='empty':
        # Lessons remain until the solver moves them. A duty can be cleared only
        # when its matching checkbox in Detailed Conditions is turned off.
        current=model.rows();indices={t['id']:i for i,t in enumerate(data['teachers'])}
        for t,s in cells:
            kind,_,subject,_=parse_cell(current[t][s])
            if kind=='unknown':raise ValueError('内容を判定できない予定は空きコマにできません。')
            if kind=='blocked':
                i=indices[t];data['teachers'][i]['cells'][s]=''
                data['weekly_template']['rows'][2*i][s+1]=None
                data['weekly_template']['rows'][2*i+1][s+1]=None
            if kind=='duty':
                key=duty_rule(subject)
                if key is None or model.rules[key]:raise ValueError(f'「{subject}を固定する」のチェックを外してから空きコマにしてください。')
                i=indices[t];data['teachers'][i]['cells'][s]=''
                data['weekly_template']['rows'][2*i][s+1]=None
                data['weekly_template']['rows'][2*i+1][s+1]=None
        absent.update(cells);fixed.difference_update(cells)
    elif action=='allow':absent.difference_update(cells)
    elif action=='fixed':
        if cells & absent:raise ValueError('先に「空きコマ指定を解除」してください。')
        fixed.update(cells)
    elif action=='unfixed':fixed.difference_update(cells)
    elif action=='delete':
        current=model.rows(mark_fixed=False);indices={t['id']:i for i,t in enumerate(data['teachers'])}
        targets=[(t,s) for t,s in cells if parse_cell(current[t][s])[0] in ('lesson','blocked') or (parse_cell(current[t][s])[0]=='duty' and duty_rule(parse_cell(current[t][s])[2]) is not None)]
        if not targets:raise ValueError('選択範囲に削除できる授業がありません。')
        for t,slot in targets:
            i=indices[t];data['teachers'][i]['cells'][slot]=''
            data['weekly_template']['rows'][2*i][slot+1]=None
            data['weekly_template']['rows'][2*i+1][slot+1]=None
            absent.discard((t,slot));fixed.discard((t,slot))
    elif action=='lesson':
        value=f'{classes} {subject}'
        if parse_cell(value)[0]!='lesson':raise ValueError('クラスと教科を選択してください。')
        indices={t['id']:i for i,t in enumerate(data['teachers'])}
        for t,s in cells:
            i=indices[t];data['teachers'][i]['cells'][s]=value
            data['weekly_template']['rows'][2*i][s+1]=classes
            data['weekly_template']['rows'][2*i+1][s+1]=subject
        absent.difference_update(cells)
    else:raise ValueError('操作が不正です。')
    data['weekly_template']['blocked']=[(i,s) for i,t in enumerate(data['teachers']) for s,v in enumerate(t['cells']) if parse_cell(v)[0]=='blocked']
    data['weekly_template']['gray']=[i for i,t in enumerate(data['teachers']) if all(parse_cell(v)[0]=='blocked' for v in t['cells'])]
    data.update(absent=sorted(absent),manual_fixed=sorted(fixed))
    result=Model(data);result.data['history']=difference_history(result)
    return result
