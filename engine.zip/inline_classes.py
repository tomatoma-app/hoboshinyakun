"""Live class timetable below the teacher timetable, with two A4 print areas."""
import copy,re
import xml.etree.ElementTree as ET

OFFSET=105
FIRST=OFFSET+4
NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
q=lambda tag:'{'+NS+'}'+tag

def column_name(n):
    result=''
    while n:n,a=divmod(n-1,26);result=chr(65+a)+result
    return result

def duty_formula(column,kind):
    terms=[]
    for r in range(4,102,2):
        ref=f'TRIM(SUBSTITUTE({column}{r+1},"　"," "))'
        match=f'{ref}="支援"' if kind=='支援' else f'OR({ref}="外国人{kind}",{ref}="外国人{"１" if kind=="1" else "２"}")'
        terms.append(f'IF({match},"・"&$D{r},"")')
    text='&'.join(terms)
    return f'=IF({text}="","橋場・稲垣",MID({text},2,32767))' if kind=='支援' else f'=MID({text},2,32767)'

def class_formula(column,row,source=''):
    """Excel 2021-compatible arrays; one subject per joint lesson, no helpers."""
    prefix="'"+source.replace("'","''")+"'!" if source else ''
    tops=f'{prefix}{column}$4:{column}$100';bottoms=f'{prefix}{column}$5:{column}$101'
    # ASC normalizes the full-width class numbers used by the template.
    return ('=_xlfn.LET('
      f'_xlpm.cls,$D{row},'
      f'_xlpm.top,TRIM(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(ASC({tops}),"－","-"),"−","-"),"・","."),"･",".")),'
      f'_xlpm.raw,TRIM(SUBSTITUTE({bottoms},"　"," ")),'
      '_xlpm.sub,IF((_xlpm.raw="体育")+(_xlpm.raw="保健体育"),"保体",IF(_xlpm.raw="作業2","作業",_xlpm.raw)),'
      f'_xlpm.even,MOD(ROW({tops}),2)=0,'
      '_xlpm.hit,_xlpm.even*IF(_xlpm.cls="10・11・12",_xlpm.top="10.11.12",'
      '(LEFT(_xlpm.top,2)=LEFT(_xlpm.cls,2))*ISNUMBER(SEARCH("."&MID(_xlpm.cls,3,9)&".","."&MID(_xlpm.top,3,99)&"."))),' 
      '_xlpm.grade,_xlpm.even*(_xlpm.cls<>"10・11・12")*(_xlpm.top=LEFT(_xlpm.cls,1)&"年"),'
      '_xlfn.TEXTJOIN("／",TRUE,_xlfn._xlws.SORT(_xlfn.UNIQUE(_xlfn._xlws.FILTER(_xlpm.sub,IF(SUM(_xlpm.hit)>0,_xlpm.hit,_xlpm.grade)*(_xlpm.sub<>""),"")))))')

def shift_ref(value):
    return re.sub(r'([A-Z]+)(\d+)',lambda m:m[1]+str(int(m[2])+OFFSET),value)

def append_classes(sheet,layout,styles,payload,compare=True):
    from preserve_format import insert,MARK,yellow_rule
    rows=payload['class_table']['rows'];last=OFFSET+3+len(rows)
    data=sheet.find(q('sheetData'))
    # Class labels such as 1-1 must remain text when typed directly in Excel.
    xfs=styles.find(q('cellXfs'));text_styles={}
    for row in data:
        r=int(row.get('r'))
        if not (4<=r<=100 and r%2==0):continue
        for cell in row:
            col=re.match('[A-Z]+',cell.get('r'))[0]
            if col in ('A','B','C','D','AH'):continue
            sid=int(cell.get('s','0'))
            if xfs[sid].get('numFmtId')=='49':continue
            if sid not in text_styles:
                xf=copy.deepcopy(xfs[sid]);xf.set('numFmtId','49');xf.set('applyNumberFormat','1')
                text_styles[sid]=len(xfs);xfs.append(xf)
            cell.set('s',str(text_styles[sid]))
    xfs.set('count',str(len(xfs)))
    if not any(c.get('r')=='D102' for c in data.iter(q('c'))):
        for old in list(data):
            if 102<=int(old.get('r'))<=104:data.remove(old)
        existing_merges=sheet.find(q('mergeCells'))
        if existing_merges is not None:
            for old in list(existing_merges):
                if 102<=int(re.search(r'\d+',old.get('ref'))[0])<=104:existing_merges.remove(old)
        fonts=styles.find(q('fonts'));font=copy.deepcopy(fonts[0])
        size=font.find(q('sz'))
        if size is not None:size.set('val','10')
        fonts.append(font);fonts.set('count',str(len(fonts)))
        source_cells={c.get('r'):c for c in layout.iter(q('c'))};footer_styles={}
        for r,kind in ((102,'支援'),(103,'1'),(104,'2')):
            row=ET.Element(q('row'),{'r':str(r),'ht':'36','customHeight':'1'})
            for n in range(4,35):
                col=column_name(n);sid=int(source_cells[col+'4'].get('s','0'))
                if sid not in footer_styles:
                    xf=copy.deepcopy(xfs[sid]);xf.set('fontId',str(len(fonts)-1));footer_styles[sid]=len(xfs);xfs.append(xf)
                cell=ET.SubElement(row,q('c'),{'r':f'{col}{r}','s':str(footer_styles[sid])})
                if n in (4,34):
                    cell.set('t','inlineStr');ET.SubElement(ET.SubElement(cell,q('is')),q('t')).text='支援' if kind=='支援' else '外国人'+kind
                else:ET.SubElement(cell,q('f')).text=duty_formula(col,kind)[1:]
            data.insert(next((i for i,x in enumerate(data) if int(x.get('r'))>r),len(data)),row)
        xfs.set('count',str(len(xfs)))
    # This area belongs to the live class timetable on every later export.
    for row in list(data):
        if int(row.get('r'))>=OFFSET:data.remove(row)
    for row in layout.find(q('sheetData')):
        if int(row.get('r'))>3+len(rows):continue
        row=copy.deepcopy(row);row.set('r',str(int(row.get('r'))+OFFSET))
        for cell in row:
            cell.set('r',shift_ref(cell.get('r')))
            col=re.match('[A-Z]+',cell.get('r'))[0]
            if int(row.get('r'))>=FIRST and col not in ('D','AH'):
                cell.attrib.pop('t',None)
                for child in list(cell):
                    if child.tag in (q('v'),q('is'),q('f')):cell.remove(child)
                ET.SubElement(cell,q('f'),{'t':'array','ref':cell.get('r')}).text=class_formula(col,int(row.get('r')))[1:]
        data.append(row)
    merges=sheet.find(q('mergeCells'))
    if merges is None:merges=ET.Element(q('mergeCells'));insert(sheet,merges)
    for node in list(merges):
        if int(re.search(r'\d+',node.get('ref'))[0])>=OFFSET:merges.remove(node)
    for node in layout.findall(q('mergeCells')+'/'+q('mergeCell')):
        if int(re.search(r'\d+',node.get('ref'))[0])<=3+len(rows):ET.SubElement(merges,q('mergeCell'),{'ref':shift_ref(node.get('ref'))})
    merges.set('count',str(len(merges)))
    cols=sheet.find(q('cols'))
    if cols is not None:
        for col in list(cols):
            if col.get('min')=='36' and col.get('max')=='64':cols.remove(col)
    sheet.find(q('dimension')).set('ref',f'A1:AH{last}')
    for cf in list(sheet.findall(q('conditionalFormatting'))):
        if any(MARK+'_連動クラス別' in (f.text or '') for f in cf.iter(q('formula'))):sheet.remove(cf)
    if compare:
        dummy=ET.Element(q('worksheet'));yellow_rule(dummy,styles)
        dxf=dummy.find(q('conditionalFormatting')+'/'+q('cfRule')).get('dxfId')
        for row in range(FIRST,last+1):
            cf=ET.Element(q('conditionalFormatting'),{'sqref':f'E{row}:AG{row}'})
            rule=ET.SubElement(cf,q('cfRule'),{'type':'expression','dxfId':dxf,'priority':str(100+row)})
            ET.SubElement(rule,q('formula')).text=f'AND(N("{MARK}_連動クラス別")=0,E{row}<>\'原本(さわらない)\'!E{row})'
            insert(sheet,cf)
        for row in range(102,105):
            cf=ET.Element(q('conditionalFormatting'),{'sqref':f'E{row}:AG{row}'})
            rule=ET.SubElement(cf,q('cfRule'),{'type':'expression','dxfId':dxf,'priority':str(100+row)})
            ET.SubElement(rule,q('formula')).text=f'AND(N("{MARK}_担当者")=0,E{row}<>\'原本(さわらない)\'!E{row})'
            insert(sheet,cf)
    setup=sheet.find(q('pageSetup'))
    if setup is None:setup=ET.Element(q('pageSetup'));insert(sheet,setup)
    setup.attrib.update(paperSize='9',orientation='landscape',fitToWidth='1',fitToHeight='1')
    setup.attrib.pop('scale',None)
    props=sheet.find(q('sheetPr'))
    if props is None:props=ET.Element(q('sheetPr'));insert(sheet,props)
    fit=props.find(q('pageSetUpPr'))
    if fit is None:fit=ET.SubElement(props,q('pageSetUpPr'))
    fit.set('fitToPage','1')
    breaks=sheet.find(q('rowBreaks'))
    if breaks is None:breaks=ET.Element(q('rowBreaks'));insert(sheet,breaks)
    breaks.clear();breaks.attrib.update(count='1',manualBreakCount='1')
    ET.SubElement(breaks,q('brk'),{'id':str(OFFSET),'min':'0','max':'16383','man':'1'})
    return last

def print_area(name,last):
    return f"'{name}'!$D$1:$AH$104,'{name}'!$D${OFFSET+1}:$AH${last}"

def dynamic_arrays(files,rels,content,sheet):
    """Use native dynamic arrays, not legacy CSE/implicit-intersection formulas."""
    from workbook_package import REL,PKG,CT,write_xml
    import posixpath
    link=next((r for r in rels if r.get('Type')==REL+'/sheetMetadata'),None)
    if link is None:
        rid=1;used={r.get('Id') for r in rels}
        while f'rId{rid}' in used:rid+=1
        link=ET.SubElement(rels,'{'+PKG+'}Relationship',{'Id':f'rId{rid}','Type':REL+'/sheetMetadata','Target':'metadata.xml'})
    part=posixpath.normpath('xl/'+link.get('Target')) if not link.get('Target').startswith('/') else link.get('Target')[1:]
    meta=ET.fromstring(files[part]) if part in files else ET.Element(q('metadata'))
    types=meta.find(q('metadataTypes'))
    if types is None:types=ET.Element(q('metadataTypes'));meta.insert(0,types)
    typ=next((i for i,x in enumerate(types,1) if x.get('name')=='XLDAPR'),None)
    if typ is None:
        ET.SubElement(types,q('metadataType'),dict(name='XLDAPR',minSupportedVersion='120000',**{k:'1' for k in ('copy','pasteAll','pasteValues','merge','splitFirst','rowColShift','clearFormats','clearComments','assign','coerce','cellMeta')}));typ=len(types)
    types.set('count',str(len(types)))
    future=next((x for x in meta.findall(q('futureMetadata')) if x.get('name')=='XLDAPR'),None)
    if future is None:
        future=ET.Element(q('futureMetadata'),{'name':'XLDAPR'});meta.insert(next((i for i,x in enumerate(meta) if x.tag in (q('cellMetadata'),q('valueMetadata'),q('extLst'))),len(meta)),future)
    xda='http://schemas.microsoft.com/office/spreadsheetml/2017/dynamicarray'
    idx=next((i for i,bk in enumerate(future) if any(x.tag=='{'+xda+'}dynamicArrayProperties' and x.get('fDynamic')=='1' for x in bk.iter())),None)
    if idx is None:
        idx=len(future);bk=ET.SubElement(future,q('bk'));ext=ET.SubElement(ET.SubElement(bk,q('extLst')),q('ext'),{'uri':'{bdbb8cdc-fa1e-496e-a857-3c3f30c029c3}'})
        ET.SubElement(ext,'{'+xda+'}dynamicArrayProperties',{'fDynamic':'1','fCollapsed':'0'})
    future.set('count',str(len(future)))
    cells=meta.find(q('cellMetadata'))
    if cells is None:cells=ET.SubElement(meta,q('cellMetadata'))
    cm=next((i for i,bk in enumerate(cells,1) if len(bk)==1 and bk[0].get('t')==str(typ) and bk[0].get('v')==str(idx)),None)
    if cm is None:
        ET.SubElement(ET.SubElement(cells,q('bk')),q('rc'),{'t':str(typ),'v':str(idx)});cm=len(cells)
    cells.set('count',str(len(cells)))
    for cell in sheet.iter(q('c')):
        f=cell.find(q('f'))
        if f is not None and '_xlpm.cls' in (f.text or ''):cell.set('cm',str(cm))
    if not any(x.get('PartName')=='/'+part for x in content):ET.SubElement(content,'{'+CT+'}Override',{'PartName':'/'+part,'ContentType':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheetMetadata+xml'})
    write_xml(files,part,meta)
