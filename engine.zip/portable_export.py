"""Offline Excel writer. Original package parts are retained by finish_package."""
import json
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.formatting.rule import FormulaRule
from openpyxl.utils import get_column_letter
from weekly_excel import finish_export
from shared_workbook import BASIC, CURRENT, SETTINGS
from engine import SLOTS

WHITE=PatternFill('solid',fgColor='FFFFFF')
YELLOW=PatternFill('solid',fgColor='FFF2A8')
GRAY=PatternFill('solid',fgColor='D3D3C8')
THIN=Side(style='thin',color='000000')
MEDIUM=Side(style='medium',color='000000')
BOUNDARIES={4,5,11,17,23,28,34,35}

def grid_sheet(sh,last,font_size,row_height):
    sh.sheet_view.showGridLines=False
    for col in range(1,35):
        sh.column_dimensions[get_column_letter(col)].width=2 if col<4 else 18 if col in (4,34) else 11
    for row in sh.iter_rows(min_row=1,max_row=last,min_col=4,max_col=34):
        for cell in row:
            cell.font=Font(name='Yu Gothic',size=font_size,color='000000')
            cell.fill=WHITE;cell.alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
    for row in range(1,last+1):sh.row_dimensions[row].height=row_height
    sh.row_dimensions[1].height=24
    sh.row_dimensions[2].height=sh.row_dimensions[3].height=20
    sh.freeze_panes='E4'
    col=5
    for day,count in zip('月火水木金',(6,6,6,5,6)):
        sh.cell(2,col,day+'曜日')
        for offset in range(count):sh.cell(3,col+offset,offset+1)
        col+=count
    for row in range(2,4):
        for col in range(4,35):
            sh.cell(row,col).border=Border(left=MEDIUM if col in BOUNDARIES else THIN,
                right=MEDIUM if col+1 in BOUNDARIES else THIN,
                top=MEDIUM if row==2 else Side(),bottom=MEDIUM if row==3 else Side())

def export_workbook(payload,path):
    wb=Workbook();wb.remove(wb.active)
    for name in (CURRENT,'クラス別',BASIC,SETTINGS):wb.create_sheet(name)
    for table in payload['tables']:
        sh=wb[table['name']];grid_sheet(sh,101,10,16)
        if sh.title==CURRENT:
            sh.sheet_properties.tabColor='FFD966'
            for c in 'ABC':sh.column_dimensions[c].width=8
        sh['D1']=sh.title;sh['D1'].font=Font(name='Yu Gothic',size=12,bold=True)
        sh['D1'].alignment=Alignment(horizontal='left',vertical='center')
        if sh.title==BASIC:
            for col,label in enumerate(SLOTS,5):sh.cell(3,col,label)
        else:
            for col,label in enumerate(SLOTS,5):sh.cell(3,col,chr(ord(label[1])+65248))
        for row,values in enumerate(table['rows'],4):
            for col,value in enumerate(values,4):sh.cell(row,col,value)
        for i in range(49):
            for row in (4+2*i,5+2*i):
                for col in range(4,35):
                    cell=sh.cell(row,col)
                    cell.border=Border(left=MEDIUM if col in BOUNDARIES else THIN,
                        right=MEDIUM if col+1 in BOUNDARIES else THIN,
                        bottom=MEDIUM if row==101 else THIN if row%2 else Side())
                    if col in (4,34):cell.alignment=Alignment(horizontal='left',vertical='center')
        for i in table['gray']:
            for row in sh.iter_rows(min_row=4+2*i,max_row=5+2*i,min_col=4,max_col=34):
                for cell in row:cell.fill=GRAY
        for i,j in table['blocked']:
            sh.merge_cells(start_row=4+2*i,start_column=5+j,end_row=5+2*i,end_column=5+j)
            sh.cell(4+2*i,5+j,'＼')  # Replaced by a native diagonal by finish_export.
        sh.merge_cells('D103:AH103');sh['D103']='黄色：「原本(さわらない)」との差。編集は「変更はここに！」で行います。'
        sh['D103'].font=Font(name='Yu Gothic',size=10)
        if sh.title==CURRENT:
            sh.conditional_formatting.add('E4:AG101',FormulaRule(
                formula=['E4<>INDIRECT("\'原本(さわらない)\'!"&ADDRESS(ROW(),COLUMN(),4))'],fill=YELLOW))
    sh=wb[SETTINGS]
    sh['A1']='時間割変更アシスタントの設定'
    sh['A2']='設定はアプリから変更してください。時間割の内容は2枚の時間割シートから読み込みます。'
    sh.column_dimensions['A'].width=110
    metadata=json.dumps(payload['settings'],ensure_ascii=False,separators=(',',':'))
    for row,start in enumerate(range(0,len(metadata),16000),4):sh.cell(row,1,metadata[start:start+16000])
    for i,j in next(t for t in payload['tables'] if t['name']==BASIC)['blocked']:
        sh.cell(4+2*i,3+j,'／');sh.cell(5+2*i,3+j,'／')
    if payload.get('class_table'):
        table=payload['class_table'];sh=wb['クラス別'];rows=table['rows'];last=3+len(rows)
        grid_sheet(sh,last,14,62)
        sh.merge_cells('D1:AH1');sh['D1']='クラスの授業時間一覧';sh['D1'].alignment=Alignment(horizontal='left',vertical='center')
        sh.row_dimensions[1].height=28
        sh.row_dimensions[2].height=sh.row_dimensions[3].height=22
        for i,values in enumerate(rows):
            row=4+i
            for col,value in enumerate(values,4):
                cell=sh.cell(row,col,value)
                cell.border=Border(left=MEDIUM if col in BOUNDARIES else THIN,
                    right=MEDIUM if col+1 in BOUNDARIES else THIN,
                    bottom=MEDIUM if i==len(rows)-1 or str(rows[i+1][0])[:1]!=str(values[0])[:1] else THIN)
        # The combined sheet uses live conditional formatting against the original.
        if table.get('missing'):
            sh.merge_cells(start_row=last+2,start_column=4,end_row=last+2,end_column=34)
            sh.cell(last+2,4,'先生別・クラス別の元データに授業がない箇所は空欄です。')
    wb.save(path);wb.close()
    finish_export(path,payload)
