"""Browser adapter. The desktop search and Excel modules are copied unchanged."""
import copy,json,time,base64,sys,zlib
from pathlib import Path
from engine import Model,SLOTS,RULES,parse_cell,fixed_by_conditions
from shared_workbook import load_shared,edit_cells,swap_cells,swap_details,rebase,bulk_edit_targets,protected_replacement
from weekly_excel import weekly_payload
from portable_export import export_workbook
from search_settings import PROFILES,MODE_LABELS

model=None
result=None
undo=[]

def view(m=None):
    m=m or model
    rows=m.rows(mark_fixed=False)
    fixed=set(m.manual_fixed)
    from selfstudy import reassignable_records
    movable_study={(r['teacher'],r['slot']) for r in reassignable_records(m)}
    fixed.update((t,m.positions[k]) for k,l in m.lessons.items() if l.locked for t in l.teachers if (t,m.positions[k]) not in movable_study)
    for t,cells in rows.items():
        for s,value in enumerate(cells):
            kind,classes,subject,_=parse_cell(value)
            if kind!='blocked' and fixed_by_conditions(classes,subject,m.rules):fixed.add((t,s))
    baseline=m.baseline_rows()
    groups=set(c for l in m.lessons.values() for c in l.classes if '-' in c)|{'10・11・12'}
    subjects={'国語','数学','理科','社会','英語','音楽','美術','保体','技家','技術','家庭','道徳','学活','総合','音美総','自習'}
    for cells in rows.values():
        for value in cells:
            kind,classes,subject,_=parse_cell(value)
            if kind=='lesson':groups.add(value.lstrip('!').split()[0]);subjects.add(subject)
    return dict(teachers=[dict(id=t['id'],name=t['name'],grade=m.data.get('teacher_grades',{}).get(t['id'],'未設定'),cells=rows[t['id']],original=baseline[t['id']]) for t in m.data['teachers']],
                title=m.data.get('title',''),classes=sorted(groups),subjects=sorted(subjects),
                absent=sorted(m.absent),fixed=sorted(fixed),study=sorted(m.study_requests),changed=sorted(m.changed_cells()),violations=sorted(m.violation_cells(m.positions)),
                conditions=m.rules,room_limits=m.room_limits,study_settings=m.data['study_settings'],
                errors=m.errors(m.positions),filename=m.data.get('source','時間割.xlsx'),undo=bool(undo))

def checkpoint():return model.saved()
def remember():
    undo.append(copy.deepcopy(model.saved()))
    if len(undo)>25:del undo[0]

def dispatch(command,args):
    global model,result
    if command=='config':return dict(slots=SLOTS,rules=RULES,modes=MODE_LABELS,python=sys.version.split()[0])
    if command=='load':
        model=Model(load_shared('/data/source.xlsx')[0]);model.data['source']=args['name'];undo.clear();result=None
    elif command=='restore':
        model=Model(args['snapshot']);result=None
        undo[:]=json.loads(zlib.decompress(base64.b64decode(args['undo_token']))) if args.get('undo_token') else []
    elif command=='edit':
        cells={tuple(c) for c in args['cells']};action=args['action']
        if action=='study' and not args.get('confirmed'):
            from selfstudy import has_joint_study,study_selection
            if has_joint_study(model,cells):
                selection=study_selection(model,cells);lines=[]
                if selection['remove']:lines.append('選択した担当者のコマを削除し、残る担当者の授業を固定します。')
                if selection['study']:lines.append('担当者全員を選んだ合同授業は、自習1コマにまとめて別の先生が対応します。')
                return dict(confirm='合同授業が含まれています。\n'+'\n'.join(lines))
        if action=='swap':
            details=swap_details(model,cells)
            if details is None:raise ValueError('入れ替え可能な2コマを選んでください。')
            if details[2] and not args.get('confirmed'):return dict(confirm='合同授業が含まれています。選択した担当者のコマだけを入れ替えます。')
            next_model=swap_cells(model,cells)[0]
        else:next_model=edit_cells(model,cells,action,args.get('classes'),args.get('subject'))
        remember();model=next_model;result=None
    elif command=='undo':
        if undo:model=Model(undo.pop());result=None
    elif command=='conditions':
        data=copy.deepcopy(model.saved());data['conditions']=args['conditions'];data['room_limits']=args['room_limits'];data['study_settings']=args['study_settings']
        if data['conditions']['same_day_only'] and not model.rules['same_day_only']:data['day_reference']=dict(model.positions)
        next_model=Model(data);remember();model=next_model;result=None
    elif command=='menu':
        cells={tuple(c) for c in args['cells']}
        return dict(swap=swap_details(model,cells) is not None,lesson=not protected_replacement(model,cells),
                    **{action:bool(bulk_edit_targets(model,cells,action)) for action in ('empty','study','allow','fixed','unfixed','delete')})
    elif command=='detail':
        m=model
        if args.get('candidate') is not None and result:
            c=result['candidates'][args['candidate']];m=Model(copy.deepcopy(c.get('model_data') or model.saved()));m.apply_batch(c)
        t,s=args['cell'];return {'reasons':m.cell_violation_reasons(t,s)}
    elif command=='preflight':
        errors=model.lesson_count_errors()
        return dict(errors=errors,pending=bool(model.pending_lessons(model.positions)))
    elif command=='search':
        mode=args['mode'];profile=PROFILES[mode];seconds=args.get('seconds',profile['seconds']);started=time.perf_counter()
        def progress(info):
            try:
                from js import reportProgress
                reportProgress(json.dumps(info))
            except ImportError:pass
        result=model.solve_absences(seconds=seconds,profile=profile,progress=progress)
        candidates=result.get('candidates',[])
        if result.get('complete') and not candidates:candidates=[result];result['candidates']=candidates
        return dict(candidates=[dict(index=i,changed=c.get('changed_cell_count',0),teachers=c.get('teacher_count',0)) for i,c in enumerate(candidates)],
                    seconds=time.perf_counter()-started,solutions=result.get('solutions_compared',len(candidates)),nodes=result.get('nodes',0),issues=result.get('issues',[]),diagnostics=result.get('diagnostics',[]),complete=result['complete'])
    elif command in ('preview','apply'):
        candidate=result['candidates'][args['index']]
        m=Model(copy.deepcopy(candidate.get('model_data') or model.saved()));m.apply_batch(candidate)
        if command=='preview':return dict(view=view(m))
        remember();model=m;result=None
    elif command=='export':
        export_workbook(weekly_payload(model),'/data/output.xlsx')
        return dict(size=Path('/data/output.xlsx').stat().st_size)
    elif command=='benchmark':
        # Local verification entrypoint: supplied data stays in browser memory.
        return benchmark(args)
    else:raise ValueError('操作が不正です。')
    return dict(view=view(),snapshot=checkpoint(),undo_token=base64.b64encode(zlib.compress(json.dumps(undo,ensure_ascii=False).encode())).decode())

def benchmark(args):
    reports=[]
    for case in args['cases']:
        m=Model(copy.deepcopy(case['data']));start=time.perf_counter()
        if case['kind']=='direct':
            plans=m.search(case['lid'],three=True)
            reports.append(dict(name=case['name'],seconds=time.perf_counter()-start,plans=[sorted(p.items()) for p in plans]))
        else:
            r=m.solve_absences(seconds=case['seconds'],profile=PROFILES['quick'])
            candidates=r.get('candidates',[])
            errors=[]
            for c in candidates:
                cm=Model(copy.deepcopy(c.get('model_data') or m.saved()))
                errors.extend(cm.errors(c['positions']))
                cm.apply_batch(c)
            reports.append(dict(name=case['name'],seconds=time.perf_counter()-start,nodes=r.get('nodes',0),solutions=r.get('solutions_compared',len(candidates)),complete=r['complete'],
                                rank=[(c['changed_cell_count'],c['teacher_count']) for c in candidates],errors=errors))
    return reports
