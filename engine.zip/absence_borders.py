"""Editable absence marks as native Excel outlines, with reversible borders."""
import copy,json,xml.etree.ElementTree as ET
from pathlib import Path

NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
def q(name):return '{'+NS+'}'+name

def red(side):
    if side is None or side.style not in ('medium','thick'):return False
    color=side.color
    if color is None:return False
    if color.type=='rgb':return color.rgb[-6:].upper()=='FF0000'
    if color.type=='indexed':return color.indexed in (2,10)
    return False

def detected(sheet,teachers,slots):
    result=[]
    for i,teacher in enumerate(teachers):
        for s in range(slots):
            a,b=(sheet.cell(4+2*i+j,5+s).border for j in (0,1))
            if all(red(x) for x in (a.top,b.bottom,a.left,a.right,b.left,b.right)):
                result.append((teacher['id'],s))
    return result

def backups(model):
    """Capture source borders before painting; read source metadata on every save."""
    from openpyxl import load_workbook
    from openpyxl.xml.functions import tostring
    from shared_workbook import CURRENT,BASIC,SETTINGS,LEGACY
    path=Path(model.data['source_path'])
    if not path.is_file():return {}
    wb=load_workbook(path)
    try:
        old={}
        if SETTINGS in wb:
            sh=wb[SETTINGS]
            meta=json.loads(''.join(str(sh.cell(r,1).value or '') for r in range(4,sh.max_row+1)))
            old=meta.get('absence_border_backups',{})
        name=next((n for n in (CURRENT,LEGACY[CURRENT],'時間割') if n in wb),None)
        if name is None:return old
        sh=wb[name];base=wb[BASIC] if BASIC in wb else sh
        targets=set(model.absent)|set(detected(sh,model.data['teachers'],len(__import__('engine').SLOTS)))
        indices={t['id']:i for i,t in enumerate(model.data['teachers'])}
        result=dict(old)
        for t,s in targets:
            for j in (0,1):
                cell=sh.cell(4+2*indices[t]+j,5+s);border=copy.copy(cell.border)
                prior=old.get(cell.coordinate)
                if prior:
                    from openpyxl.styles import Border
                    previous=Border.from_tree(ET.fromstring(prior))
                else:previous=base[cell.coordinate].border
                for side in ('left','right','top','bottom'):
                    if red(getattr(border,side)):
                        replacement=copy.copy(getattr(previous,side))
                        if red(replacement):
                            from openpyxl.styles import Side
                            replacement=Side()
                        setattr(border,side,replacement)
                result[cell.coordinate]=tostring(border.to_tree()).decode()
        return result
    finally:wb.close()

def apply(sheet,styles,payload,restore=False):
    from openpyxl.utils.cell import get_column_letter
    borders=styles.find(q('borders'));xfs=styles.find(q('cellXfs'))
    bids={ET.tostring(b):i for i,b in enumerate(borders)}
    xids={ET.tostring(x):i for i,x in enumerate(xfs)}
    cells={c.get('r'):c for c in sheet.iter(q('c'))}
    def put(cell,border):
        key=ET.tostring(border)
        if key not in bids:bids[key]=len(borders);borders.append(border)
        xf=copy.deepcopy(xfs[int(cell.get('s','0'))]);xf.set('borderId',str(bids[key]));xf.set('applyBorder','1')
        key=ET.tostring(xf)
        if key not in xids:xids[key]=len(xfs);xfs.append(xf)
        cell.set('s',str(xids[key]))
    if restore:
        for address,xml in payload['settings'].get('absence_border_backups',{}).items():
            cell=cells.get(address)
            if cell is None:continue
            previous=ET.fromstring(xml)
            for node in previous.iter():node.tag=q(node.tag.split('}')[-1])
            border=copy.deepcopy(borders[int(xfs[int(cell.get('s','0'))].get('borderId','0'))])
            changed=False
            for side in ('left','right','top','bottom'):
                node=border.find(q(side));color=node.find(q('color')) if node is not None else None
                if node is not None and node.get('style') in ('medium','thick') and color is not None and (color.get('rgb','')[-6:].upper()=='FF0000' or color.get('indexed') in ('2','10')):
                    index=list(border).index(node);border.remove(node)
                    replacement=previous.find(q(side))
                    border.insert(index,copy.deepcopy(replacement) if replacement is not None else ET.Element(q(side)));changed=True
            if changed:put(cell,border)
    else:
        indices={t:i for i,t in enumerate(payload['settings']['teacher_grades'])}
        for t,s in payload['settings']['absent']:
            for j in (0,1):
                address=f'{get_column_letter(5+s)}{4+2*indices[t]+j}';cell=cells[address]
                border=copy.deepcopy(borders[int(xfs[int(cell.get('s','0'))].get('borderId','0'))])
                for side in ('left','right','top' if j==0 else 'bottom'):
                    node=border.find(q(side))
                    if node is None:node=ET.SubElement(border,q(side))
                    node.clear();node.set('style','thick');ET.SubElement(node,q('color'),{'rgb':'FFFF0000'})
                put(cell,border)
    borders.set('count',str(len(borders)));xfs.set('count',str(len(xfs)))
