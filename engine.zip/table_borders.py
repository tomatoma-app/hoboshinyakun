"""Continuous timetable outlines and day/grade separators; retain diagonals."""
import copy,xml.etree.ElementTree as ET
from inline_classes import FIRST,OFFSET,column_name
from preserve_format import q

def repair_borders(sheet,styles,payload):
    for font in styles.find(q('fonts')):
        name=font.find(q('name'))
        if name is None:name=ET.SubElement(font,q('name'))
        name.set('val','ＭＳ Ｐゴシック')
        for scheme in list(font.findall(q('scheme'))):font.remove(scheme)
    data=sheet.find(q('sheetData'));rows={int(r.get('r')):r for r in data}
    cells={c.get('r'):c for c in data.iter(q('c'))}
    borders=styles.find(q('borders'));xfs=styles.find(q('cellXfs'));cache={}
    border_ids={ET.tostring(b):i for i,b in enumerate(borders)}
    xf_ids={ET.tostring(x):i for i,x in enumerate(xfs)}
    def edges(r,c,sides):
        address=f'{column_name(c)}{r}';cell=cells.get(address)
        if cell is None:
            row=rows.get(r)
            if row is None:return
            cell=ET.Element(q('c'),{'r':address});row.append(cell);cells[address]=cell
        sid=int(cell.get('s','0'));key=(sid,tuple(sorted(sides)))
        if key not in cache:
            xf=copy.deepcopy(xfs[sid]);border=copy.deepcopy(borders[int(xf.get('borderId','0'))])
            order=['start','end','left','right','top','bottom','diagonal','vertical','horizontal']
            for side in sides:
                node=border.find(q(side))
                if node is None:
                    node=ET.Element(q(side));border.insert(next((i for i,x in enumerate(border) if x.tag.split('}')[-1] in order and order.index(x.tag.split('}')[-1])>order.index(side)),len(border)),node)
                if node.get('style') not in ('medium','thick','double'):node.set('style','medium')
                if node.find(q('color')) is None:ET.SubElement(node,q('color'),{'rgb':'FF000000'})
            bkey=ET.tostring(border)
            if bkey not in border_ids:border_ids[bkey]=len(borders);borders.append(border)
            xf.set('borderId',str(border_ids[bkey]));xf.set('applyBorder','1');xkey=ET.tostring(xf)
            if xkey not in xf_ids:xf_ids[xkey]=len(xfs);xfs.append(xf)
            cache[key]=xf_ids[xkey]
        cell.set('s',str(cache[key]))
    last=FIRST+len(payload['class_table']['rows'])-1
    starts={4,5,11,17,23,28,34}
    for first,end in ((2,104),(OFFSET+2,last)):
        for r in range(first,end+1):
            for c in range(4,35):
                sides=[]
                if c in starts:sides.append('left')
                if c==34 or c+1 in starts:sides.append('right')
                if r==first:sides.append('top')
                if r==end:sides.append('bottom')
                if sides:edges(r,c,sides)
    lines={4,102,FIRST};previous=None
    grades=payload.get('settings',{}).get('teacher_grades',{})
    for i,(teacher,grade) in enumerate(grades.items()):
        if grade in ('1','2','3','特別支援'):
            if grade!=previous:lines.add(4+2*i)
            previous=grade
    previous=None
    for i,row in enumerate(payload['class_table']['rows']):
        grade=row[0].split('-')[0]
        if previous is not None and grade!=previous:lines.add(FIRST+i)
        previous=grade
    for r in lines:
        for c in range(4,35):edges(r,c,['top']);edges(r-1,c,['bottom'])
    # Rows must remain in worksheet column order after inserting missing borders.
    from preserve_format import number
    import re
    for row in rows.values():row[:]=sorted(row,key=lambda c:number(re.match('[A-Z]+',c.get('r'))[0]))
    for node in (borders,xfs):node.set('count',str(len(node)))
