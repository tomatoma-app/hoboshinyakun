"""Read the two-row weekly template; retain original cell text for faithful export."""
import copy,hashlib,re,unicodedata,io
from pathlib import Path
from engine import Model,SLOTS,parse_cell

def norm(v):return unicodedata.normalize('NFKC',str(v or '')).strip().replace('－','-').replace('−','-')

def read_table(sh):
    source_slots=SLOTS
    day_columns=[5,11,17,23,28]
    right_column=34
    right_name='AH'
    for c,day in zip(day_columns,['月曜日','火曜日','水曜日','木曜日','金曜日']):
        if norm(sh.cell(2,c).value)!=day:raise ValueError(f'{sh.cell(2,c).coordinate} は「{day}」にしてください。')
    original_sheet=sh.title in ('原本(さわらない)','基本時間割')
    for j,slot in enumerate(source_slots):
        value=norm(sh.cell(3,5+j).value)
        allowed={slot[1:],slot} if original_sheet else {slot[1:]}
        if value not in allowed:raise ValueError(f'{sh.cell(3,5+j).coordinate} の時限が違います。')
    teachers=[];raw=[];blocked=[];gray=[]
    for i in range(49):
        r=4+2*i;name=norm(sh.cell(r,4).value)
        if not name or norm(sh.cell(r,right_column).value)!=name:raise ValueError(f'D{r} と {right_name}{r} に同じ先生名を入力してください。')
        if sh.cell(r+1,4).value or sh.cell(r+1,right_column).value:raise ValueError(f'D{r+1} と {right_name}{r+1} は空欄にしてください。')
        pair=[[sh.cell(rr,c).value for c in range(4,right_column+1)] for rr in (r,r+1)]
        if any(sh.cell(rr,c).data_type=='f' for rr in (r,r+1) for c in range(4,right_column+1)):raise ValueError(f'{name}：数式ではなく文字で入力してください。')
        cells=[]
        for j in range(len(source_slots)):
            a,b=sh.cell(r,5+j),sh.cell(r+1,5+j);top,sub=norm(a.value),norm(b.value)
            slash=any(c.border.diagonalDown or c.border.diagonalUp for c in (a,b)) or top in ('/','\\','＼','×','X') or sub in ('/','\\','＼','×','X')
            if slash:
                if any(x and x not in ('/','\\','＼','×','X') for x in (top,sub)):raise ValueError(f'{a.coordinate}：斜線と授業が重なっています。')
                value='/';blocked.append([i,j]);pair[0][j+1]=pair[1][j+1]=None
            elif not top and not sub:value=''
            elif not top:
                if sub in {'数学','理科','国語','英語','社会','音楽','美術','体育','保体','保健体育','技術','家庭','技家','道徳'}:raise ValueError(f'{a.coordinate}：教科に対応するクラスが空欄です。')
                value='!'+sub
            elif re.fullmatch('[123]年',top):value='!'+top+sub
            else:
                top=top.replace('･','・').replace('・','.')
                if top in ('10.11.12','10,11,12'):top='10・11・12'
                value=top+' '+sub
                if not sub or parse_cell(value)[0]!='lesson':raise ValueError(f'{a.coordinate}／{b.coordinate}：上段はクラス、下段は教科を入力してください。')
            cells.append(value)
        if all(c=='/' for c in cells):gray.append(i)
        teachers.append({'id':f'T{i+1:02d}','name':name,'cells':cells});raw.extend(pair)
    if len({t['name'] for t in teachers})!=49:raise ValueError('先生名が重複しています。')
    return {'teachers':teachers,'weekly_template':{'rows':raw,'blocked':blocked,'gray':gray}}

def load_week(path,conditions=None):
    from shared_workbook import load_shared
    return load_shared(path,conditions)[0]

def weekly_payload(model):
    from shared_workbook import template_rows, settings, initialize, TABLES
    from class_export import class_payload
    initialize(model.data)
    current=dict(copy.deepcopy(model.data['weekly_template']),rows=template_rows(model))
    tables=[model.data['basic_table']['weekly_template'],current]
    return {'tables':[dict(t,name=n) for t,n in zip(tables,TABLES)],'rows':current['rows'],
            'blocked':current['blocked'],'gray':current['gray'],'title':model.data['title'],
            'source':model.data['source'],'source_path':model.data['source_path'],
            'class_table':class_payload(model),'settings':settings(model),'cycle_map':model.data['cycle_map']}

def finish_export(path,payload):
    from workbook_package import finish_package
    finish_package(path,payload)
