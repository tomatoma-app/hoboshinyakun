import json,hashlib,re
from pathlib import Path
from collections import defaultdict
from engine import SLOTS

def normalize_reference(reference):
    result={}
    for key,values in reference.items():
        values=list(values)
        result[key]=values
    return result

def teacher_key(teachers):return hashlib.sha256(json.dumps(teachers,ensure_ascii=False,sort_keys=True).encode()).hexdigest()

def class_payload(model):
    if model.data.get('weekly_baseline'):
        from engine import Model
        import copy
        base=Model(dict(copy.deepcopy(model.data['weekly_baseline']),rules_version=3,class_reference=model.data.get('baseline_class_reference',{})))
        before=class_payload(base)
        ref={r[0]:r[1:-1] for r in before['rows']}
        for lesson in base.lessons.values():
            for c in lesson.classes:
                key='10・11・12' if c in ('10','11','12') else c
                ref[key][lesson.origin]=''
        data=copy.deepcopy(model.saved());data.pop('weekly_baseline',None);data['class_reference']=ref
        result=class_payload(Model(data));original={r[0]:r[1:-1] for r in before['rows']}
        result['yellow']=[[i,j] for i,r in enumerate(result['rows']) for j,value in enumerate(r[1:-1]) if value!=original.get(r[0],['']*len(SLOTS))[j]]
        return result
    reference=normalize_reference(dict(model.data.get('class_reference',{})))
    if not reference:
        base=json.loads((Path(__file__).parent/'クラス別原表.json').read_text(encoding='utf-8'))
        if teacher_key(model.data['teachers'])==base['teacher_key']:reference=normalize_reference(base['reference'])
    classes=set(reference)
    for l in model.lessons.values():classes.update('10・11・12' if c in ('10','11','12') else c for c in l.classes)
    keys=sorted(classes,key=lambda c:(9,0) if c=='10・11・12' else tuple(map(int,c.split('-'))))
    before={c:list(reference.get(c,['']*len(SLOTS))) for c in keys}
    # Grade-wide entries in the selected teacher workbook, not an assumed weekly pattern.
    for teacher in model.data['teachers']:
        for slot,value in enumerate(teacher['cells']):
            m=re.fullmatch(r'!([123])年(.+)',value)
            if m:
                for c in keys:
                    if c.startswith(m[1]+'-'):before[c][slot]=m[2]
    for l in model.lessons.values():
        for c in l.classes:before['10・11・12' if c in ('10','11','12') else c][l.origin]=''
    rows={c:list(values) for c,values in before.items()};buckets=defaultdict(set);yellow=set()
    for k,slot in model.positions.items():
        l=model.lessons[k]
        for c in l.classes:
            c='10・11・12' if c in ('10','11','12') else c;buckets[c,slot].add(l.subject)
            if slot!=l.origin:yellow.update([(keys.index(c),slot),(keys.index(c),l.origin)])
    for (c,slot),subjects in buckets.items():rows[c][slot]='／'.join(sorted(subjects))
    return {'rows':[[c]+rows[c]+[c] for c in keys],'yellow':sorted(yellow),'missing':sum(not v for row in rows.values() for v in row)}
