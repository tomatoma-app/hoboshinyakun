"""Bounded profiles; time is a maximum and cancellation is cooperative."""
MODE_LABELS={'quick':'短め（30秒）','standard':'標準（2分）','careful':'じっくり（5分）'}
PROFILES={
    'quick':dict(seconds=30,moves=10,single_seconds=10,linked_seconds=2,normal_limit=32,linked_limit=40),
    'standard':dict(seconds=120,moves=12,single_seconds=20,linked_seconds=5,normal_limit=64,linked_limit=80),
    'careful':dict(seconds=300,moves=16,single_seconds=60,linked_seconds=10,normal_limit=96,linked_limit=160),
}
