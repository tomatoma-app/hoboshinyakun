"""Retain the loaded worksheet and replace only application-owned values."""
import copy,re
import xml.etree.ElementTree as ET
NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
q=lambda tag:'{'+NS+'}'+tag
MARK='ほぼしんや君_変更箇所'
FORMULA='AND(N("'+MARK+'")=0,OR(INDEX($E$4:$AG$101,ROW()-3-MOD(ROW()-4,2),COLUMN()-4)<>INDIRECT("\'原本(さわらない)\'!"&ADDRESS(ROW()-MOD(ROW()-4,2),COLUMN(),4)),INDEX($E$4:$AG$101,ROW()-2-MOD(ROW()-4,2),COLUMN()-4)<>INDIRECT("\'原本(さわらない)\'!"&ADDRESS(ROW()+1-MOD(ROW()-4,2),COLUMN(),4))))'
LEGACY='E4<>INDIRECT("\'原本(さわらない)\'!"&ADDRESS(ROW(),COLUMN(),4))'
ORDER='sheetPr dimension sheetViews sheetFormatPr cols sheetData sheetCalcPr sheetProtection protectedRanges scenarios autoFilter sortState dataConsolidate customSheetViews mergeCells phoneticPr conditionalFormatting dataValidations hyperlinks printOptions pageMargins pageSetup headerFooter rowBreaks colBreaks customProperties cellWatches ignoredErrors smartTags drawing legacyDrawing legacyDrawingHF picture oleObjects controls webPublishItems tableParts extLst'.split()
def insert(sheet,node):
    name=node.tag.split('}')[-1];rank=ORDER.index(name)
    i=next((i for i,n in enumerate(sheet) if n.tag.split('}')[-1] in ORDER and ORDER.index(n.tag.split('}')[-1])>rank),len(sheet));sheet.insert(i,node)
def legacy_pair_formula(row):
    return f'OR(E${row}<>INDIRECT("\'原本(さわらない)\'!"&ADDRESS({row},COLUMN(),4)),E${row+1}<>INDIRECT("\'原本(さわらない)\'!"&ADDRESS({row+1},COLUMN(),4)))'
def direct_pair_formula(row):
    return f"OR(E${row}<>'原本(さわらない)'!E${row},E${row+1}<>'原本(さわらない)'!E${row+1})"

def pair_formula(row):
    def normalized(ref):
        return f'TRIM(CLEAN(SUBSTITUTE(SUBSTITUTE({ref}&"","　"," "),CHAR(160)," ")))'
    return 'OR('+','.join(normalized(f'E${r}')+'<>'+normalized(f"'原本(さわらない)'!E${r}") for r in (row,row+1))+')'

def yellow_rule(sheet,styles):
    managed={f'E{r}:AG{r+1}':pair_formula(r) for r in range(4,102,2)}
    legacy={f'E{r}:AG{r+1}':legacy_pair_formula(r) for r in range(4,102,2)}
    direct={f'E{r}:AG{r+1}':direct_pair_formula(r) for r in range(4,102,2)}
    for cf in list(sheet.findall(q('conditionalFormatting'))):
        for rule in list(cf):
            formulas=[f.text or '' for f in rule.findall(q('formula'))]
            if any(MARK in f for f in formulas) or (cf.get('sqref')=='E4:AG101' and formulas==[LEGACY]) or formulas==[managed.get(cf.get('sqref'))] or formulas==[legacy.get(cf.get('sqref'))] or formulas==[direct.get(cf.get('sqref'))] or any(re.sub(r'^[A-Z]+[0-9]+(?=<>)','E4',f)==LEGACY for f in formulas):cf.remove(rule)
        if not len(cf):sheet.remove(cf)
    dxfs=styles.find(q('dxfs'))
    if dxfs is None:
        dxfs=ET.Element(q('dxfs'),{'count':'0'});index=next((i for i,n in enumerate(styles) if n.tag in (q('tableStyles'),q('colors'),q('extLst'))),len(styles));styles.insert(index,dxfs)
    dxf=ET.Element(q('dxf'));fill=ET.SubElement(dxf,q('fill'));pat=ET.SubElement(fill,q('patternFill'),{'patternType':'solid'});ET.SubElement(pat,q('fgColor'),{'rgb':'FFFFF2A8'});ET.SubElement(pat,q('bgColor'),{'rgb':'FFFFF2A8'})
    key=ET.tostring(dxf);idx=next((i for i,n in enumerate(dxfs) if ET.tostring(n)==key),None)
    if idx is None:idx=len(dxfs);dxfs.append(dxf)
    dxfs.set('count',str(len(dxfs)))
    for rule in sheet.iter(q('cfRule')):rule.set('priority',str(int(rule.get('priority','1'))+49))
    for priority,(area,formula) in enumerate(managed.items(),1):
        cf=ET.Element(q('conditionalFormatting'),{'sqref':area})
        rule=ET.SubElement(cf,q('cfRule'),{'type':'expression','dxfId':str(idx),'priority':str(priority),'stopIfTrue':'0'});ET.SubElement(rule,q('formula')).text=formula;insert(sheet,cf)
def number(letter):
    n=0
    for c in letter:n=n*26+ord(c)-64
    return n
def preserve_sheet(old,new,styles,name,payload):
    sheet=copy.deepcopy(old);data=sheet.find(q('sheetData'));rows={int(r.get('r')):r for r in data}
    last=101 if name!='クラス別' else 3+len(payload['class_table']['rows'])
    updates={c.get('r'):c for c in new.iter(q('c'))}
    for rownum in range(4,last+1):
        row=rows.get(rownum)
        if row is None:
            row=ET.Element(q('row'),{'r':str(rownum)});data.insert(next((i for i,r in enumerate(data) if int(r.get('r'))>rownum),len(data)),row);rows[rownum]=row
        cells={c.get('r'):c for c in row}
        for col in range(4,35):
            letter=''
            n=col
            while n:n,a=divmod(n-1,26);letter=chr(65+a)+letter
            address=f'{letter}{rownum}';src=updates.get(address);cell=cells.get(address)
            if cell is None:
                cell=ET.Element(q('c'),{'r':address})
                if src is not None and src.get('s') is not None:cell.set('s',src.get('s'))
                row.insert(next((i for i,c in enumerate(row) if number(re.match('[A-Z]+',c.get('r')).group())>col),len(row)),cell)
            cell.attrib.pop('t',None)
            for child in list(cell):
                if child.tag in (q('v'),q('is'),q('f')):cell.remove(child)
            if src is not None:
                if src.get('t') is not None:cell.set('t',src.get('t'))
                for child in src:
                    if child.tag in (q('v'),q('is'),q('f')):cell.append(copy.deepcopy(child))
    if name!='クラス別':
        table=next(t for t in payload['tables'] if t['name']==name)
        blocked={tuple(x) for x in table['blocked']};borders=styles.find(q('borders'));xfs=styles.find(q('cellXfs'));cache={}
        cells={c.get('r'):c for c in sheet.iter(q('c'))};merges=sheet.find(q('mergeCells'))
        def style(cell,slash):
            sid=int(cell.get('s','0'));xf=xfs[sid];border=borders[int(xf.get('borderId','0'))]
            had=any(border.get(k) in ('1','true') for k in ('diagonalDown','diagonalUp'))
            if slash==had:return
            key=(sid,slash)
            if key not in cache:
                border=copy.deepcopy(border);border.attrib.pop('diagonalUp',None);border.attrib.pop('diagonalDown',None)
                for diag in list(border.findall(q('diagonal'))):border.remove(diag)
                if slash:
                    border.set('diagonalDown','1');diag=ET.Element(q('diagonal'),{'style':'thin'});border.insert(next((i for i,n in enumerate(border) if n.tag in (q('vertical'),q('horizontal'))),len(border)),diag);ET.SubElement(diag,q('color'),{'rgb':'FF000000'})
                xf=copy.deepcopy(xf);xf.set('borderId',str(len(borders)));xf.set('applyBorder','1');borders.append(border);cache[key]=len(xfs);xfs.append(xf)
            cell.set('s',str(cache[key]))
        for i in range(49):
            for j in range(29):
                col=j+5;letter=('A'+chr(64+col-26)) if col>26 else chr(64+col)
                a=f'{letter}{4+2*i}';b=f'{letter}{5+2*i}';top=cells[a];bottom=cells[b]
                border=borders[int(xfs[int(top.get('s','0'))].get('borderId','0'))];was=border.get('diagonalDown')=='1' or border.get('diagonalUp')=='1';slash=(i,j) in blocked
                lower=borders[int(xfs[int(bottom.get('s','0'))].get('borderId','0'))]
                was=was or any(lower.get(k) in ('1','true') for k in ('diagonalDown','diagonalUp'))
                # Keep existing diagonal directions, thickness, colors and merges.
                if slash==was:continue
                if merges is not None and was and not slash:
                    for merge in list(merges):
                        if merge.get('ref')==a+':'+b:merges.remove(merge)
                if slash:
                    if merges is None:merges=ET.Element(q('mergeCells'));insert(sheet,merges)
                    if not any(n.get('ref')==a+':'+b for n in merges):ET.SubElement(merges,q('mergeCell'),{'ref':a+':'+b})
                style(top,slash);style(bottom,slash)
        for node in (borders,xfs):node.set('count',str(len(node)))
        if merges is not None:
            if len(merges):merges.set('count',str(len(merges)))
            else:sheet.remove(merges)
    if name=='クラス別':
        for cf in list(sheet.findall(q('conditionalFormatting'))):
            for rule in list(cf):
                if any(MARK+'_クラス別' in (f.text or '') for f in rule.findall(q('formula'))):cf.remove(rule)
            if not len(cf):sheet.remove(cf)
        changed=payload['class_table'].get('yellow',[])
        if changed:
            dummy=ET.Element(q('worksheet'));yellow_rule(dummy,styles);cf=dummy.find(q('conditionalFormatting'))
            refs=[]
            for i,j in changed:
                n=j+5;letter=''
                while n:n,a=divmod(n-1,26);letter=chr(65+a)+letter
                refs.append(f'{letter}{i+4}')
            cf.set('sqref',' '.join(sorted(set(refs))))
            cf.find(q('cfRule')).find(q('formula')).text='N("'+MARK+'_クラス別")=0'
            for rule in sheet.iter(q('cfRule')):rule.set('priority',str(int(rule.get('priority','1'))+1))
            insert(sheet,cf)
    return sheet
