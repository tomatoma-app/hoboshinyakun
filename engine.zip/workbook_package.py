"""Native printing/diagonals and lossless retention of unrelated package parts.

Worksheet content and conditional formats are authored by portable_export. This
merger keeps existing worksheets/relationships outside the managed timetable.
"""
import copy, posixpath, re, zipfile, io, html
import xml.etree.ElementTree as ET
from pathlib import Path
from shared_workbook import TABLES, SETTINGS, BASIC, CURRENT, LEGACY

NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
REL='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
PKG='http://schemas.openxmlformats.org/package/2006/relationships'
CT='http://schemas.openxmlformats.org/package/2006/content-types'
q=lambda tag:'{'+NS+'}'+tag
ET.register_namespace('',NS);ET.register_namespace('r',REL)

def read_zip(path):
    with zipfile.ZipFile(path) as z:return {n:z.read(n) for n in z.namelist()}
def write_xml(files,path,node):
    namespace=node.tag[1:].split('}')[0] if node.tag.startswith('{') else NS
    declarations={}
    if path in files:
        declarations=dict(value for _,value in ET.iterparse(io.BytesIO(files[path]),events=['start-ns']))
        for prefix,uri in declarations.items():
            if prefix and not re.fullmatch(r'ns\d+',prefix):ET.register_namespace(prefix,uri)
    ET.register_namespace('',namespace)
    xml=ET.tostring(node,encoding='utf-8',xml_declaration=True)
    # Excel uses namespace prefixes inside mc:Ignorable attribute values. ET
    # otherwise drops unused declarations, making a saved Office file invalid.
    extra=b''
    for prefix,uri in declarations.items():
        if prefix and not re.search(rb'xmlns:'+re.escape(prefix.encode())+rb'=',xml):extra+=(' xmlns:'+prefix+'="'+html.escape(uri,quote=True)+'"').encode()
    if extra:
        end=xml.index(b'>',xml.index(b'?>')+2);xml=xml[:end]+extra+xml[end:]
    files[path]=xml
    ET.register_namespace('',NS)
def sheet_paths(files):
    wb=ET.fromstring(files['xl/workbook.xml']);rels=ET.fromstring(files['xl/_rels/workbook.xml.rels'])
    targets={r.get('Id'):posixpath.normpath('xl/'+r.get('Target')) if not r.get('Target').startswith('/') else r.get('Target')[1:] for r in rels}
    return {s.get('name'):targets[s.get('{'+REL+'}id')] for s in wb.find(q('sheets'))}

def style_maps(old,new):
    maps={}
    def collection(name):
        node=old.find(q(name))
        if node is None:
            order=['numFmts','fonts','fills','borders','cellStyleXfs','cellXfs','cellStyles','dxfs','tableStyles','colors','extLst']
            node=ET.Element(q(name));rank=order.index(name)
            i=next((i for i,c in enumerate(old) if c.tag.split('}')[-1] in order and order.index(c.tag.split('}')[-1])>rank),len(old));old.insert(i,node)
        return node
    fmtmap={};src=new.find(q('numFmts'))
    if src is not None:
        dst=collection('numFmts');used={int(x.get('numFmtId')) for x in dst};codes={x.get('formatCode'):int(x.get('numFmtId')) for x in dst}
        for node in src:
            oldid=int(node.get('numFmtId'));code=node.get('formatCode')
            if code not in codes:
                num=max(used|{163})+1;used.add(num);codes[code]=num;n=copy.deepcopy(node);n.set('numFmtId',str(num));dst.append(n)
            fmtmap[oldid]=codes[code]
        dst.set('count',str(len(dst)))
    for name in ('fonts','fills','borders','cellStyleXfs','cellXfs','dxfs'):
        src=new.find(q(name));dst=collection(name);indices={ET.tostring(c):i for i,c in enumerate(dst)};mapping={}
        for i,source in enumerate(src if src is not None else []):
            node=copy.deepcopy(source)
            if name in ('cellStyleXfs','cellXfs'):
                for attr,group in [('fontId','fonts'),('fillId','fills'),('borderId','borders'),('xfId','cellStyleXfs')]:
                    if attr in node.attrib and group in maps:node.set(attr,str(maps[group][int(node.get(attr))]))
                if 'numFmtId' in node.attrib:node.set('numFmtId',str(fmtmap.get(int(node.get('numFmtId')),int(node.get('numFmtId')))))
            key=ET.tostring(node)
            if key not in indices:indices[key]=len(dst);dst.append(node)
            mapping[i]=indices[key]
        dst.set('count',str(len(dst)));maps[name]=mapping
    return maps

def native_sheet(sheet,style,blocked,settings=False):
    borders=style.find(q('borders'));xfs=style.find(q('cellXfs'));cells={c.get('r'):c for c in sheet.iter(q('c'))};cache={}
    def letter(n):
        s=''
        while n:n,a=divmod(n-1,26);s=chr(65+a)+s
        return s
    for i,j in blocked:
        cell=cells.get(f'{letter(j+5)}{4+i*2}')
        if cell is None:continue
        sid=int(cell.get('s','0'))
        if sid not in cache:
            xf=copy.deepcopy(xfs[sid]);border=copy.deepcopy(borders[int(xf.get('borderId','0'))]);border.set('diagonalDown','1')
            diag=border.find(q('diagonal'))
            if diag is None:diag=ET.SubElement(border,q('diagonal'))
            diag.set('style','thin')
            if diag.find(q('color')) is None:ET.SubElement(diag,q('color'),{'rgb':'FF000000'})
            xf.set('borderId',str(len(borders)));xf.set('applyBorder','1');borders.append(border);cache[sid]=len(xfs);xfs.append(xf)
        cell.set('s',str(cache[sid]));cell.attrib.pop('t',None)
        for child in list(cell):
            if child.tag in (q('v'),q('is'),q('f')):cell.remove(child)
    for group in (borders,xfs):group.set('count',str(len(group)))
    if settings:return
    order=['sheetPr','dimension','sheetViews','sheetFormatPr','cols','sheetData','sheetCalcPr','sheetProtection','protectedRanges','scenarios','autoFilter','sortState','dataConsolidate','customSheetViews','mergeCells','phoneticPr','conditionalFormatting','dataValidations','hyperlinks','printOptions','pageMargins','pageSetup','headerFooter','rowBreaks','colBreaks','customProperties','cellWatches','ignoredErrors','smartTags','drawing','legacyDrawing','legacyDrawingHF','picture','oleObjects','controls','webPublishItems','tableParts','extLst']
    def ensure(tag):
        matches=sheet.findall(q(tag));node=matches[0] if matches else ET.Element(q(tag))
        for duplicate in matches[1:]:sheet.remove(duplicate)
        if not matches:
            index=next((i for i,c in enumerate(sheet) if c.tag.split('}')[-1] in order and order.index(c.tag.split('}')[-1])>order.index(tag)),len(sheet));sheet.insert(index,node)
        return node
    ensure('pageMargins').attrib.update(left='0.2',right='0.2',top='0.2',bottom='0.2',header='0',footer='0')
    ensure('pageSetup').attrib.update(paperSize='8',orientation='landscape',fitToWidth='1',fitToHeight='1')
    prop=ensure('sheetPr');ps=prop.find(q('pageSetUpPr'))
    if ps is None:ps=ET.SubElement(prop,q('pageSetUpPr'))
    ps.set('fitToPage','1')

def finish_package(path,payload):
    path=Path(path);generated=read_zip(path);gp=sheet_paths(generated)
    gs=ET.fromstring(generated['xl/styles.xml'])
    # Solid differential fills should have an explicit foreground as well as
    # the background emitted by Artifact Tool (Excel renderers differ here).
    dxfs=gs.find(q('dxfs'))
    if dxfs is not None:
        for pattern in dxfs.iter(q('patternFill')):
            bg=pattern.find(q('bgColor'))
            if pattern.get('patternType')=='solid' and pattern.find(q('fgColor')) is None and bg is not None:
                fg=copy.deepcopy(bg);fg.tag=q('fgColor');pattern.insert(0,fg)
    sheets={name:ET.fromstring(generated[part]) for name,part in gp.items()}
    for table in payload['tables']:native_sheet(sheets[table['name']],gs,table['blocked'])
    if 'クラス別' in sheets:native_sheet(sheets['クラス別'],gs,[])
    for name in (BASIC,'クラス別'):
        if name in sheets and sheets[name].find(q('sheetProtection')) is None:
            protection=ET.Element(q('sheetProtection'),{'sheet':'1','objects':'1','scenarios':'1'})
            children=list(sheets[name]);index=max((i for i,node in enumerate(children) if node.tag in (q('sheetData'),q('sheetCalcPr'))),default=-1)+1
            sheets[name].insert(index,protection)
    source=Path(payload['source_path'])
    files=read_zip(source) if source.is_file() else dict(generated)
    oldpaths=sheet_paths(files);wb=ET.fromstring(files['xl/workbook.xml']);rels=ET.fromstring(files['xl/_rels/workbook.xml.rels']);content=ET.fromstring(files['[Content_Types].xml'])
    oldstyles=ET.fromstring(files['xl/styles.xml']);maps=style_maps(oldstyles,gs)
    strings=ET.fromstring(generated['xl/sharedStrings.xml']) if 'xl/sharedStrings.xml' in generated else []
    wb_sheets=wb.find(q('sheets'))
    # Rename previous app sheet names while keeping old workbooks readable.
    for new_name,old_name in LEGACY.items():
        if new_name not in oldpaths and old_name in oldpaths:
            for node in wb_sheets:
                if node.get('name')==old_name:node.set('name',new_name)
            oldpaths[new_name]=oldpaths.pop(old_name)
            for part in list(files):
                if part.startswith('xl/worksheets/') and part.endswith('.xml'):
                    tree=ET.fromstring(files[part]);changed=False
                    for formula in tree.iter(q('f')):
                        if formula.text:
                            value=formula.text.replace("'"+old_name+"'!","'"+new_name+"'!")
                            if value!=formula.text:formula.text=value;changed=True
                    if changed:write_xml(files,part,tree)
            for node in wb.iter(q('definedName')):
                if node.text:node.text=node.text.replace("'"+old_name+"'!","'"+new_name+"'!")
    # A one-sheet restored workbook becomes the protected original on first save.
    if BASIC not in oldpaths and '時間割' in oldpaths:
        for node in wb_sheets:
            if node.get('name')=='時間割':node.set('name',BASIC)
        oldpaths[BASIC]=oldpaths.pop('時間割')
        for part in list(files):
            if part.startswith('xl/worksheets/') and part.endswith('.xml'):
                tree=ET.fromstring(files[part]);changed=False
                for formula in tree.iter(q('f')):
                    if formula.text:
                        value=re.sub(r"(?<![\w])(?:'時間割'|時間割)!", "'原本(さわらない)'!",formula.text)
                        if value!=formula.text:formula.text=value;changed=True
                if changed:write_xml(files,part,tree)
        for node in wb.iter(q('definedName')):
            if node.text:node.text=node.text.replace("'時間割'!","'原本(さわらない)'!")
    used_ids={r.get('Id') for r in rels}
    class_layout=sheets.pop('クラス別',None)
    if class_layout is not None:
        for cell in class_layout.iter(q('c')):
            cell.set('s',str(maps['cellXfs'][int(cell.get('s','0'))]))
    for name,sheet in sheets.items():
        for cell in sheet.iter(q('c')):
            cell.set('s',str(maps['cellXfs'][int(cell.get('s','0'))]))
            if cell.get('t')=='s':
                value=cell.find(q('v'));index=int(value.text);cell.remove(value);cell.set('t','inlineStr');inline=ET.SubElement(cell,q('is'))
                for child in strings[index]:inline.append(copy.deepcopy(child))
        for rule in sheet.iter(q('cfRule')):
            if rule.get('dxfId') is not None:rule.set('dxfId',str(maps['dxfs'][int(rule.get('dxfId'))]))
        if name in oldpaths:
            part=oldpaths[name]
            old_sheet=ET.fromstring(files[part])
            if name==BASIC:
                sheet=copy.deepcopy(old_sheet)
            elif name in TABLES or name=='クラス別':
                from preserve_format import preserve_sheet
                sheet=preserve_sheet(old_sheet,sheet,oldstyles,name,payload)
            # Form-control buttons and their drawing relationships belong to
            # the source macro workbook. Retain those nodes when rebuilding.
            drawing_tags={q(x) for x in ('drawing','legacyDrawing','legacyDrawingHF','controls','oleObjects')}
            existing={node.tag for node in sheet if node.tag in drawing_tags}
            for node in old_sheet:
                if node.tag in drawing_tags and node.tag not in existing:sheet.append(copy.deepcopy(node))
        else:
            n=1
            while f'xl/worksheets/sheet{n}.xml' in files:n+=1
            part=f'xl/worksheets/sheet{n}.xml';rid=1
            while f'rId{rid}' in used_ids:rid+=1
            rid=f'rId{rid}';used_ids.add(rid)
            ET.SubElement(rels,'{'+PKG+'}Relationship',{'Id':rid,'Type':REL+'/worksheet','Target':part[3:]})
            ET.SubElement(wb_sheets,q('sheet'),{'name':name,'sheetId':str(max(int(s.get('sheetId')) for s in wb_sheets)+1),'{'+REL+'}id':rid})
            ET.SubElement(content,'{'+CT+'}Override',{'PartName':'/'+part,'ContentType':'application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml'})
        if name in TABLES:
            if name==CURRENT:
                from absence_borders import apply as absence_borders
                absence_borders(sheet,oldstyles,payload,restore=True)
                from preserve_format import yellow_rule
                yellow_rule(sheet,oldstyles)
            if class_layout is not None:
                from inline_classes import append_classes,dynamic_arrays
                append_classes(sheet,class_layout,oldstyles,payload,compare=name==CURRENT)
                dynamic_arrays(files,rels,content,sheet)
                from table_borders import repair_borders
                repair_borders(sheet,oldstyles,payload)
            if name==CURRENT:absence_borders(sheet,oldstyles,payload)
        write_xml(files,part,sheet)
    # Put the four user-facing sheets first. Keep unrelated sheets afterwards.
    old_index_to_name={i:node.get('name') for i,node in enumerate(list(wb_sheets))}
    for node in list(wb_sheets):
        if node.get('name')=='クラス別':
            rid=node.get('{'+REL+'}id');wb_sheets.remove(node)
            part=oldpaths.get('クラス別')
            for rel in list(rels):
                if rel.get('Id')==rid:rels.remove(rel)
            if part:
                files.pop(part,None)
                files.pop(posixpath.dirname(part)+'/_rels/'+posixpath.basename(part)+'.rels',None)
                for item in list(content):
                    if item.get('PartName')=='/'+part:content.remove(item)
    ordered=[]
    for name in (CURRENT,'クラス別',BASIC):
        ordered.extend(node for node in list(wb_sheets) if node.get('name')==name)
    ordered.extend(node for node in list(wb_sheets) if node not in ordered and node.get('name')!=SETTINGS)
    ordered.extend(node for node in list(wb_sheets) if node.get('name')==SETTINGS)
    for node in list(wb_sheets):wb_sheets.remove(node)
    for node in ordered:wb_sheets.append(node)
    defs=wb.find(q('definedNames'))
    if defs is None:
        defs=ET.Element(q('definedNames'));index=next((i for i,c in enumerate(wb) if c.tag==q('calcPr')),len(wb));wb.insert(index,defs)
    new_index={node.get('name'):i for i,node in enumerate(wb_sheets)}
    for defined in list(defs):
        if defined.get('localSheetId') is not None:
            old_index=int(defined.get('localSheetId'));name=old_index_to_name.get(old_index)
            if name=='クラス別':defs.remove(defined);continue
            if name in new_index:defined.set('localSheetId',str(new_index[name]))
    if class_layout is not None:
        from inline_classes import print_area,OFFSET
        for table_name in TABLES:
            for defined in list(defs):
                if defined.get('localSheetId')==str(new_index[table_name]) and defined.get('name') in ('_xlnm.Print_Area','_xlnm.Print_Titles'):defs.remove(defined)
            ET.SubElement(defs,q('definedName'),{'name':'_xlnm.Print_Area','localSheetId':str(new_index[table_name])}).text=print_area(table_name,OFFSET+3+len(payload['class_table']['rows']))
    for i,node in enumerate(wb_sheets):
        name=node.get('name')
        if name==SETTINGS:node.set('state','hidden')
        if name not in sheets:continue
        if name in oldpaths and any(d.get('name')=='_xlnm.Print_Area' and d.get('localSheetId')==str(i) for d in defs):continue
        for old in list(defs):
            if old.get('name')=='_xlnm.Print_Area' and old.get('localSheetId')==str(i):defs.remove(old)
        if name in TABLES:area='$D$1:$AH$101'
        elif name=='クラス別':area=f"$D$1:$AH${3+len(payload['class_table']['rows'])}"
        else:continue
        ET.SubElement(defs,q('definedName'),{'name':'_xlnm.Print_Area','localSheetId':str(i)}).text=f"'{name}'!{area}"
    views=wb.find(q('bookViews'))
    if views is not None:
        for view in views:view.set('activeTab',str(next(i for i,s in enumerate(wb_sheets) if s.get('name')==CURRENT)))
    calc=wb.find(q('calcPr'))
    if calc is None:calc=ET.SubElement(wb,q('calcPr'))
    calc.set('calcMode','auto');calc.set('fullCalcOnLoad','1');calc.set('forceFullCalc','1')
    for part,node in [('xl/workbook.xml',wb),('xl/_rels/workbook.xml.rels',rels),('[Content_Types].xml',content),('xl/styles.xml',oldstyles)]:write_xml(files,part,node)
    # A previous calculation chain references replaced cells; Excel rebuilds it.
    if 'xl/calcChain.xml' in files:
        files.pop('xl/calcChain.xml')
        for node in list(rels):
            if node.get('Type','').endswith('/calcChain'):rels.remove(node)
        for node in list(content):
            if node.get('PartName')=='/xl/calcChain.xml':content.remove(node)
        write_xml(files,'xl/_rels/workbook.xml.rels',rels);write_xml(files,'[Content_Types].xml',content)
    tmp=path.with_suffix('.finishing.xlsx')
    with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as z:
        for name,value in files.items():z.writestr(name,value)
    tmp.replace(path)
