"""Same-period self-study cover, with explicit teacher assignments."""
import copy,time
from collections import Counter
from engine import Model,SLOTS,parse_cell,is_study_subject,study_subject

def repair_cover(model,seconds,cancel=None,profile=None,progress=None):
    """Search repairs of cover reservations, keeping real lessons intact."""
    import heapq
    from search_settings import PROFILES
    profile=profile or PROFILES['standard'];deadline=time.monotonic()+seconds
    initial=dict(model.positions);queue=[];serial=0;seen=set();solutions=[];nodes=0
    def stopped():return time.monotonic()>=deadline or (cancel is not None and cancel.is_set())
    def push(pos):
        nonlocal serial
        signature=tuple(sorted((k,s) for k,s in pos.items() if s!=initial[k]))
        if signature in seen:return
        seen.add(signature);serial+=1
        heapq.heappush(queue,(len(model.errors(pos)),len(signature),serial,pos))
    push(initial)
    while queue and not stopped():
        violations,_,_,pos=heapq.heappop(queue);model.positions=pos;nodes+=1
        if progress:progress({'nodes':nodes,'remaining':violations})
        if not violations:
            solutions.append({'positions':dict(pos),'complete':True,'changes':{},'issues':[],'unresolved':[],'diagnostics':[]})
            if len(solutions)>=3:break
            continue
        pending=[k for k in model.pending_lessons(pos) if not model.lessons[k].locked]
        occupancy=model.occupancy(pos)[0]
        pending.sort(key=lambda k:(-sum(len(occupancy[t,pos[k]])>1 for t in model.lessons[k].teachers),pos[k],k))
        improved=False
        for k in pending:
            if stopped():break
            plans=model.search(k,False,cancel=cancel,deadline=deadline,enforce_gap=False)
            for plan in plans:
                next_pos=pos|plan
                if len(model.errors(next_pos))<violations:improved=True
                push(next_pos)
        if not improved:
            full=model.required_free_days(pos)
            for k in pending:
                if stopped():break
                needs_gap=any((t,SLOTS[pos[k]][0]) in full for t in model.lessons[k].teachers)
                targets={s for s in range(len(SLOTS)) if SLOTS[s][0]!=SLOTS[pos[k]][0]} if needs_gap else None
                plans,_=model.search_linked(k,max_moves=profile['moves'],seconds=min(.4,max(.001,deadline-time.monotonic())),limit=12,cancel=cancel,enforce_gap=False,targets=targets)
                for plan in plans:push(pos|plan)
        # Bound memory, retaining the most promising alternative repairs.
        if len(queue)>256:queue=heapq.nsmallest(128,queue);heapq.heapify(queue)
    model.positions=initial
    return {'candidates':solutions,'nodes':nodes}

def is_joint_study(model,lesson):
    members=model.joint_members.get(lesson.id,{lesson.id})
    teachers={t for k in members for t in model.lessons[k].teachers}
    return len(lesson.classes)>1 or len(teachers)>1 or len(members)>1

def has_joint_study(model,cells):
    cells=set(cells)
    return any(is_joint_study(model,l) and any((t,model.positions[k]) in cells for t in l.teachers)
               for k,l in model.lessons.items())

def active_records(model):
    rows=model.rows(mark_fixed=False)
    return [r for r in model.data.get('study_records',[]) if r.get('teacher') in rows and 0<=r.get('slot',-1)<len(SLOTS)
            and parse_cell(rows[r['teacher']][r['slot']])[1]==tuple(r['classes'])
            and is_study_subject(parse_cell(rows[r['teacher']][r['slot']])[2])]

def reassignable_records(model):
    from engine import fixed_by_conditions
    return [r for r in active_records(model)
            if (r['teacher'],r['slot']) not in model.manual_fixed
            and not fixed_by_conditions(tuple(r['classes']),study_subject(r['subject']),model.rules)]

def study_selection(model,cells):
    from shared_workbook import bulk_edit_targets
    cells=bulk_edit_targets(model,cells,'study')
    rows=model.rows(mark_fixed=False)
    free={c for c in cells if parse_cell(rows[c[0]][c[1]])[0]=='free'}
    study=set();remove=set();fixed=set();skipped=set()
    for k,l in model.lessons.items():
        selected={(t,model.positions[k]) for t in l.teachers}&cells
        if not selected:continue
        if is_joint_study(model,l):
            members=model.joint_members[k]
            partners={(t,model.positions[j]) for j in members for t in model.lessons[j].teachers
                      if model.positions[j]==model.positions[k]}
            remaining=partners-cells
            if remaining:remove.update(selected);fixed.update(remaining)
            elif partners<=cells and l.classes and all(model.positions[j]==model.positions[k] for j in members):study.update(selected)
            else:skipped.update(selected)
        elif l.classes:study.update(selected)
        else:skipped.update(selected)
    return dict(free=free,study=study,remove=remove,fixed=fixed,skipped=skipped)

def request_study(model,cells):
    from shared_workbook import rebase
    selection=study_selection(model,cells)
    applied=selection['free']|selection['study']|selection['remove']
    if not applied:return model
    data=rebase(model);requests={tuple(c) for c in data.get('study_requests',[])}-applied
    requests.update(selection['study'])
    indices={t['id']:i for i,t in enumerate(data['teachers'])}
    for t,s in selection['remove']:
        i=indices[t];data['teachers'][i]['cells'][s]=''
        data['weekly_template']['rows'][2*i][s+1]=None
        data['weekly_template']['rows'][2*i+1][s+1]=None
    for record in data.get('joint_links',[]):
        record['cells']=[c for c in record['cells'] if tuple(c) not in selection['remove']]
    data['joint_links']=[r for r in data.get('joint_links',[]) if r['cells']]
    data['study_requests']=sorted(requests)
    data['absent']=sorted((model.absent|applied)-selection['fixed'])
    data['manual_fixed']=sorted((model.manual_fixed-applied)|selection['fixed'])
    return Model(data)

def solve(model,seconds,cancel=None,profile=None,progress=None):
    from shared_workbook import rebase
    start=time.monotonic();deadline=start+seconds;data=rebase(model);rows={t['id']:t['cells'] for t in data['teachers']}
    requests={tuple(x) for x in data.get('study_requests',[])};jobs=[];seen=set();issues=[]
    for t,s in sorted(requests):
        found=[l for k,l in model.lessons.items() if t in l.teachers and model.positions[k]==s and l.classes]
        if not found:issues.append(f'{model.teachers[t]} {SLOTS[s]}：自習対応する授業を確認してください。');continue
        l=found[0];key=(s,l.classes,l.subject)
        if is_joint_study(model,l):
            members=model.joint_members[l.id]
            partners={(teacher,model.positions[k]) for k in members for teacher in model.lessons[k].teachers}
            if not partners<=requests or any(slot!=s for teacher,slot in partners):
                issues.append(f'{SLOTS[s]} {model.label(l.id)}：合同授業の担当指定が一致しません。指定を解除して、もう一度自習対応を指定してください。');continue
        if key in seen:continue
        seen.add(key)
        if l.locked:issues.append(f'{SLOTS[s]} {model.label(l.id)}：固定を解除してから自習対応を指定してください。');continue
        if any(j['slot']==s and set(j['classes']) & set(l.classes) for j in jobs):
            issues.append(f'{SLOTS[s]}：同じクラスの自習対応が重複しています。授業設定を確認してください。');continue
        teachers=sorted({teacher for k in model.joint_members[l.id] for teacher in model.lessons[k].teachers})
        jobs.append({'slot':s,'classes':list(l.classes),'subject':l.subject,'source_teachers':teachers})
    # Saved covers retain their time and original subject, but may change teacher.
    movable=reassignable_records(model)
    for record in movable:
        if any(j['slot']==record['slot'] and set(j['classes']) & set(record['classes']) for j in jobs):continue
        jobs.append(dict(record,source_teachers=[record['teacher']],previous_teacher=record['teacher']))
    moving={(r['teacher'],r['slot']) for r in movable}
    data['study_records']=[r for r in data.get('study_records',[]) if (r['teacher'],r['slot']) not in moving]
    indices={t['id']:i for i,t in enumerate(data['teachers'])}
    def write(d,t,s,value,top=None,subject=None):
        i=indices[t];d['teachers'][i]['cells'][s]=value
        d['weekly_template']['rows'][2*i][s+1]=top;d['weekly_template']['rows'][2*i+1][s+1]=subject
    for job in jobs:
        for t in job['source_teachers']:write(data,t,job['slot'],'')
    settings=model.data['study_settings'];grades=model.data.get('teacher_grades',{})
    counts=Counter(t for t,values in rows.items() for v in values if is_study_subject(parse_cell(v)[2]))
    cleared=Model(copy.deepcopy(data))
    busy=set(cleared.blocked)|model.absent|model.manual_fixed
    for k,l in cleared.lessons.items():
        if l.locked:busy.update((t,cleared.positions[k]) for t in l.teachers)
    def assignment_cost(t,slot):
        occupied=parse_cell(rows[t][slot])[0]!='free'
        # Prefer spare capacity; fixed meetings count as occupied too.
        free=sum(parse_cell(rows[t][s])[0] == 'free' for s in range(len(SLOTS)) if SLOTS[s][0]==SLOTS[slot][0])
        occupants=[l for k,l in cleared.lessons.items() if t in l.teachers and cleared.positions[k]==slot]
        complexity=sum(len(l.teachers)+len(l.classes)-1 for l in occupants)
        return (2*int(occupied)+int(free<=1)+max(0,complexity-1),int(occupied),counts[t],t)
    pools=[]
    for job in jobs:
        grade={c.split('-')[0] if '-' in c else '特別支援' for c in job['classes']}
        pool=[t for t in model.teachers if (t,job['slot']) not in busy and (not settings['limit_enabled'] or counts[t]<settings['max_count'])
              and (not settings['same_grade'] or grade=={grades.get(t,'未設定')})]
        pool.sort(key=lambda t:(int(job.get('previous_teacher',t)!=t),assignment_cost(t,job['slot'])));pools.append(pool)
        if not pool:
            detail='所属学年、固定・勤務不可、自習対応上限を確認してください。通常授業の移動も含めて担当者を探しています。'
            issues.append(f'{SLOTS[job["slot"]]} {"・".join(job["classes"])}：担当できる先生がいません。'+detail)
    candidates=[];signatures=set();nodes=0;limited=False;last_progress=0.0
    def stopped():return time.monotonic()>=deadline or (cancel is not None and cancel.is_set())
    def failed():
        return {'positions':dict(model.positions),'complete':False,'unresolved':[], 'issues':issues or ['自習対応と時間割変更を両立する案が見つかりませんでした。'],'diagnostics':[], 'limited':limited or stopped(),'nodes':nodes,'seconds':round(time.monotonic()-start,2),'solutions_compared':len(signatures),'changes':{},'candidates':candidates,'changed_cell_count':0,'teacher_count':0}
    if issues:return failed()
    order=sorted(range(len(jobs)),key=lambda i:len(pools[i]));chosen={}
    def evaluate_assignment():
        nonlocal nodes,limited,last_progress
        if stopped():limited=True;return
        nodes+=1
        assigned=copy.deepcopy(data);assigned['study_requests']=[]
        records=list(assigned.get('study_records',[]));planned=[]
        for i,job in enumerate(jobs):
            record=dict(job,teacher=chosen[i]);records.append(record);planned.append(record)
        assigned['study_records']=records;assigned['study_plan']=planned;covered=Model(assigned)
        if covered.pending_lessons(covered.positions) or covered.errors(covered.positions):
            remain=deadline-time.monotonic()
            if remain<=0:return
            def relay(info):
                nonlocal last_progress
                now=time.monotonic()
                if progress and now-last_progress>=.2:
                    last_progress=now;progress({'elapsed':now-start,'solutions':len(signatures),'nodes':nodes+info.get('nodes',0),'remaining':info.get('remaining',0)})
            result=repair_cover(covered,seconds=min(remain,max(.5,seconds/12)),cancel=cancel,profile=profile,progress=relay)
            plans=result.get('candidates',[])
        else:plans=[{'positions':dict(covered.positions),'complete':True,'changes':{},'unresolved':[],'issues':[],'diagnostics':[]}]
        for plan in plans:
            pos=plan['positions']
            if covered.errors(pos):continue
            # Only publish ordinary, non-overlapping worksheet data. Internal
            # reservations never leak into saved workbooks or candidate IDs.
            covered.positions=dict(pos);materialized=rebase(covered);materialized.pop('study_plan',None)
            final=Model(materialized);pos=dict(final.positions)
            if final.errors(pos):continue
            cells=final.changed_cells(pos);table=final.rows(pos,False);signature=tuple((t,s,table[t][s]) for t,s in sorted(cells))
            if signature in signatures:continue
            signatures.add(signature)
            candidate=dict(plan,positions=pos,changes={},model_data=final.saved(),changed_cell_count=len(cells),teacher_count=len({t for t,s in cells}))
            candidates.append(candidate);candidates.sort(key=lambda c:(c['changed_cell_count'],c['teacher_count'],tuple(sorted((r['teacher'],r['slot']) for r in c['model_data']['study_records']))));del candidates[10:]
        if progress and time.monotonic()-last_progress>=.2:
            last_progress=time.monotonic();progress({'elapsed':last_progress-start,'solutions':len(signatures),'nodes':nodes,'remaining':0 if candidates else len(jobs)})
    # Consider different complete assignments early instead of spending the
    # whole budget on permutations with the same hard-to-move first teacher.
    beam=[(0,{},Counter(counts),set())]
    for i in order:
        expanded=[];slot=jobs[i]['slot']
        for cost,allocation,loads,used in beam:
            if stopped():break
            for t in pools[i]:
                if (settings['limit_enabled'] and loads[t]>=settings['max_count']) or (t,slot) in used:continue
                next_loads=loads.copy();next_loads[t]+=1
                expanded.append((cost+assignment_cost(t,slot)[0]+4*int(jobs[i].get('previous_teacher',t)!=t),allocation|{i:t},next_loads,used|{(t,slot)}))
        expanded.sort(key=lambda item:(item[0],tuple(sorted(item[1].items()))))
        if len(expanded)>256:limited=True
        beam=expanded[:256]
        if not beam:break
    for _,allocation,_,_ in beam:
        if stopped():limited=True;break
        if len(allocation)!=len(jobs):continue
        chosen=allocation;evaluate_assignment()
    result=failed()
    if candidates:result.update(candidates[0]);result['complete']=True;result['candidates']=candidates;result['solutions_compared']=len(signatures)
    return result
